// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// -------------------------------------------------------------------------------

`timescale 1 ps / 1 ps

(* BLOCK_STUB = "true" *)
module onlyonce (
  IR,
  R0,
  R1,
  R2,
  Z,
  MDRR,
  MDRW,
  CLKK,
  RSTT,
  MAR
);

  (* X_INTERFACE_IGNORE = "true" *)
  output [15:0]IR;
  (* X_INTERFACE_IGNORE = "true" *)
  output [15:0]R0;
  (* X_INTERFACE_IGNORE = "true" *)
  output [15:0]R1;
  (* X_INTERFACE_IGNORE = "true" *)
  output [15:0]R2;
  (* X_INTERFACE_IGNORE = "true" *)
  output [15:0]Z;
  (* X_INTERFACE_IGNORE = "true" *)
  output [15:0]MDRR;
  (* X_INTERFACE_IGNORE = "true" *)
  output [15:0]MDRW;
  (* X_INTERFACE_IGNORE = "true" *)
  input CLKK;
  (* X_INTERFACE_IGNORE = "true" *)
  input RSTT;
  (* X_INTERFACE_IGNORE = "true" *)
  output [7:0]MAR;

  // stub module has no contents

endmodule
