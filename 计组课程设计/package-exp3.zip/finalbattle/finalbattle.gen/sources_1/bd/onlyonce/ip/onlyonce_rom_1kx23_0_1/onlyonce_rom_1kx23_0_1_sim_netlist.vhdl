-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Wed Nov 12 12:28:07 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_rom_1kx23_0_1/onlyonce_rom_1kx23_0_1_sim_netlist.vhdl
-- Design      : onlyonce_rom_1kx23_0_1
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_rom_1kx23_0_1_rom_1kx23 is
  port (
    data_out : out STD_LOGIC_VECTOR ( 18 downto 0 );
    addr : in STD_LOGIC_VECTOR ( 6 downto 0 );
    data_out_0_sp_1 : in STD_LOGIC;
    clk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of onlyonce_rom_1kx23_0_1_rom_1kx23 : entity is "rom_1kx23";
end onlyonce_rom_1kx23_0_1_rom_1kx23;

architecture STRUCTURE of onlyonce_rom_1kx23_0_1_rom_1kx23 is
  signal data_out_0_sn_1 : STD_LOGIC;
  signal \data_out_tristate_oe[0]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[11]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[13]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[13]_i_2_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[14]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[15]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[16]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[1]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[21]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[21]_i_2_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[2]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[3]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[6]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[7]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[8]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[8]_i_2_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe[9]_i_1_n_0\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[0]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[11]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[13]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[14]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[15]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[16]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[1]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[21]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[2]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[3]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[6]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[7]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[8]\ : STD_LOGIC;
  signal \data_out_tristate_oe_reg_n_0_[9]\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \data_out[0]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \data_out[10]_INST_0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \data_out[11]_INST_0\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \data_out[13]_INST_0\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \data_out[14]_INST_0\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \data_out[15]_INST_0\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \data_out[16]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \data_out[17]_INST_0\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \data_out[18]_INST_0\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \data_out[1]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \data_out[2]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \data_out[3]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \data_out[4]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \data_out[5]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \data_out[6]_INST_0\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \data_out[7]_INST_0\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \data_out[8]_INST_0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \data_out[9]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[13]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[14]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[15]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[16]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[1]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[21]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[2]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \data_out_tristate_oe[8]_i_2\ : label is "soft_lutpair3";
begin
  data_out_0_sn_1 <= data_out_0_sp_1;
\data_out[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[0]\,
      I1 => data_out_0_sn_1,
      O => data_out(0)
    );
\data_out[10]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[21]\,
      I1 => data_out_0_sn_1,
      O => data_out(10)
    );
\data_out[11]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[11]\,
      I1 => data_out_0_sn_1,
      O => data_out(11)
    );
\data_out[13]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[13]\,
      I1 => data_out_0_sn_1,
      O => data_out(12)
    );
\data_out[14]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[14]\,
      I1 => data_out_0_sn_1,
      O => data_out(13)
    );
\data_out[15]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[15]\,
      I1 => data_out_0_sn_1,
      O => data_out(14)
    );
\data_out[16]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[16]\,
      I1 => data_out_0_sn_1,
      O => data_out(15)
    );
\data_out[17]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[21]\,
      I1 => data_out_0_sn_1,
      O => data_out(16)
    );
\data_out[18]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[21]\,
      I1 => data_out_0_sn_1,
      O => data_out(17)
    );
\data_out[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[1]\,
      I1 => data_out_0_sn_1,
      O => data_out(1)
    );
\data_out[21]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[21]\,
      I1 => data_out_0_sn_1,
      O => data_out(18)
    );
\data_out[2]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[2]\,
      I1 => data_out_0_sn_1,
      O => data_out(2)
    );
\data_out[3]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[3]\,
      I1 => data_out_0_sn_1,
      O => data_out(3)
    );
\data_out[4]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[9]\,
      I1 => data_out_0_sn_1,
      O => data_out(4)
    );
\data_out[5]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[16]\,
      I1 => data_out_0_sn_1,
      O => data_out(5)
    );
\data_out[6]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[6]\,
      I1 => data_out_0_sn_1,
      O => data_out(6)
    );
\data_out[7]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[7]\,
      I1 => data_out_0_sn_1,
      O => data_out(7)
    );
\data_out[8]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[8]\,
      I1 => data_out_0_sn_1,
      O => data_out(8)
    );
\data_out[9]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \data_out_tristate_oe_reg_n_0_[9]\,
      I1 => data_out_0_sn_1,
      O => data_out(9)
    );
\data_out_tristate_oe[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3B3B003B3BBB0BBB"
    )
        port map (
      I0 => \data_out_tristate_oe[13]_i_2_n_0\,
      I1 => addr(0),
      I2 => addr(1),
      I3 => addr(4),
      I4 => addr(5),
      I5 => addr(6),
      O => \data_out_tristate_oe[0]_i_1_n_0\
    );
\data_out_tristate_oe[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000015"
    )
        port map (
      I0 => addr(6),
      I1 => addr(4),
      I2 => addr(5),
      I3 => addr(2),
      I4 => addr(3),
      I5 => addr(1),
      O => \data_out_tristate_oe[11]_i_1_n_0\
    );
\data_out_tristate_oe[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000062101010"
    )
        port map (
      I0 => addr(0),
      I1 => addr(1),
      I2 => \data_out_tristate_oe[13]_i_2_n_0\,
      I3 => addr(5),
      I4 => addr(4),
      I5 => addr(6),
      O => \data_out_tristate_oe[13]_i_1_n_0\
    );
\data_out_tristate_oe[13]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => addr(2),
      I1 => addr(3),
      O => \data_out_tristate_oe[13]_i_2_n_0\
    );
\data_out_tristate_oe[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"32223155"
    )
        port map (
      I0 => addr(0),
      I1 => addr(1),
      I2 => addr(5),
      I3 => addr(4),
      I4 => addr(6),
      O => \data_out_tristate_oe[14]_i_1_n_0\
    );
\data_out_tristate_oe[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000CD57"
    )
        port map (
      I0 => addr(4),
      I1 => addr(5),
      I2 => addr(6),
      I3 => addr(1),
      I4 => addr(0),
      O => \data_out_tristate_oe[15]_i_1_n_0\
    );
\data_out_tristate_oe[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => addr(1),
      I1 => addr(6),
      I2 => addr(0),
      O => \data_out_tristate_oe[16]_i_1_n_0\
    );
\data_out_tristate_oe[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFBFBFB0"
    )
        port map (
      I0 => addr(4),
      I1 => addr(5),
      I2 => addr(1),
      I3 => addr(3),
      I4 => addr(2),
      O => \data_out_tristate_oe[1]_i_1_n_0\
    );
\data_out_tristate_oe[21]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => addr(0),
      O => \data_out_tristate_oe[21]_i_1_n_0\
    );
\data_out_tristate_oe[21]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => addr(5),
      I1 => addr(4),
      I2 => addr(1),
      O => \data_out_tristate_oe[21]_i_2_n_0\
    );
\data_out_tristate_oe[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => addr(5),
      I1 => addr(4),
      I2 => addr(1),
      O => \data_out_tristate_oe[2]_i_1_n_0\
    );
\data_out_tristate_oe[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => addr(4),
      I1 => addr(6),
      O => \data_out_tristate_oe[3]_i_1_n_0\
    );
\data_out_tristate_oe[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2222222215100504"
    )
        port map (
      I0 => addr(0),
      I1 => addr(1),
      I2 => addr(4),
      I3 => addr(2),
      I4 => addr(5),
      I5 => addr(6),
      O => \data_out_tristate_oe[6]_i_1_n_0\
    );
\data_out_tristate_oe[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4455000044552131"
    )
        port map (
      I0 => addr(0),
      I1 => addr(1),
      I2 => addr(6),
      I3 => addr(4),
      I4 => addr(5),
      I5 => addr(2),
      O => \data_out_tristate_oe[7]_i_1_n_0\
    );
\data_out_tristate_oe[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000F0545000F0000"
    )
        port map (
      I0 => addr(0),
      I1 => addr(5),
      I2 => addr(1),
      I3 => addr(4),
      I4 => addr(6),
      I5 => \data_out_tristate_oe[8]_i_2_n_0\,
      O => \data_out_tristate_oe[8]_i_1_n_0\
    );
\data_out_tristate_oe[8]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => addr(3),
      I1 => addr(2),
      O => \data_out_tristate_oe[8]_i_2_n_0\
    );
\data_out_tristate_oe[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000030301"
    )
        port map (
      I0 => addr(1),
      I1 => addr(3),
      I2 => addr(2),
      I3 => addr(5),
      I4 => addr(4),
      I5 => addr(6),
      O => \data_out_tristate_oe[9]_i_1_n_0\
    );
\data_out_tristate_oe_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[0]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[0]\,
      R => '0'
    );
\data_out_tristate_oe_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[11]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[11]\,
      R => \data_out_tristate_oe[21]_i_1_n_0\
    );
\data_out_tristate_oe_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[13]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[13]\,
      R => '0'
    );
\data_out_tristate_oe_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[14]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[14]\,
      R => '0'
    );
\data_out_tristate_oe_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[15]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[15]\,
      R => '0'
    );
\data_out_tristate_oe_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[16]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[16]\,
      R => '0'
    );
\data_out_tristate_oe_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[1]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[1]\,
      R => \data_out_tristate_oe[21]_i_1_n_0\
    );
\data_out_tristate_oe_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[21]_i_2_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[21]\,
      R => \data_out_tristate_oe[21]_i_1_n_0\
    );
\data_out_tristate_oe_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[2]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[2]\,
      R => '0'
    );
\data_out_tristate_oe_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[3]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[3]\,
      R => '0'
    );
\data_out_tristate_oe_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[6]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[6]\,
      R => '0'
    );
\data_out_tristate_oe_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[7]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[7]\,
      R => '0'
    );
\data_out_tristate_oe_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[8]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[8]\,
      R => '0'
    );
\data_out_tristate_oe_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \data_out_tristate_oe[9]_i_1_n_0\,
      Q => \data_out_tristate_oe_reg_n_0_[9]\,
      R => \data_out_tristate_oe[21]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_rom_1kx23_0_1 is
  port (
    clk : in STD_LOGIC;
    en : in STD_LOGIC;
    addr : in STD_LOGIC_VECTOR ( 9 downto 0 );
    data_out : out STD_LOGIC_VECTOR ( 22 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_rom_1kx23_0_1 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_rom_1kx23_0_1 : entity is "onlyonce_rom_1kx23_0_1,rom_1kx23,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_rom_1kx23_0_1 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_rom_1kx23_0_1 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_rom_1kx23_0_1 : entity is "rom_1kx23,Vivado 2024.2";
end onlyonce_rom_1kx23_0_1;

architecture STRUCTURE of onlyonce_rom_1kx23_0_1 is
  signal \data_out[22]_INST_0_i_1_n_0\ : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0";
begin
\data_out[12]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => '0',
      I1 => \data_out[22]_INST_0_i_1_n_0\,
      I2 => '0',
      I3 => '0',
      I4 => '0',
      I5 => '0',
      O => data_out(12)
    );
\data_out[19]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => '0',
      I1 => \data_out[22]_INST_0_i_1_n_0\,
      I2 => '0',
      I3 => '0',
      I4 => '0',
      I5 => '0',
      O => data_out(19)
    );
\data_out[20]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => '0',
      I1 => \data_out[22]_INST_0_i_1_n_0\,
      I2 => '0',
      I3 => '0',
      I4 => '0',
      I5 => '0',
      O => data_out(20)
    );
\data_out[22]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => '0',
      I1 => \data_out[22]_INST_0_i_1_n_0\,
      I2 => '0',
      I3 => '0',
      I4 => '0',
      I5 => '0',
      O => data_out(22)
    );
\data_out[22]_INST_0_i_1\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => clk,
      CE => '1',
      D => en,
      Q => \data_out[22]_INST_0_i_1_n_0\,
      R => '0'
    );
inst: entity work.onlyonce_rom_1kx23_0_1_rom_1kx23
     port map (
      addr(6 downto 0) => addr(6 downto 0),
      clk => clk,
      data_out(18) => data_out(21),
      data_out(17 downto 12) => data_out(18 downto 13),
      data_out(11 downto 0) => data_out(11 downto 0),
      data_out_0_sp_1 => \data_out[22]_INST_0_i_1_n_0\
    );
end STRUCTURE;
