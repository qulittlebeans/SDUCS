// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2025 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:bus_mux16:1.0
// IP Revision: 1

`timescale 1ns/1ps

(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module onlyonce_bus_mux16_0_0 (
  PCout,
  DRout,
  Zout,
  R2out,
  R1out,
  R0out,
  IRout,
  PCout_en,
  DRout_en,
  Zout_en,
  R2out_en,
  R1out_en,
  R0out_en,
  IRout_en,
  bus_out,
  conflict
);

input wire [15 : 0] PCout;
input wire [15 : 0] DRout;
input wire [15 : 0] Zout;
input wire [15 : 0] R2out;
input wire [15 : 0] R1out;
input wire [15 : 0] R0out;
input wire [15 : 0] IRout;
input wire PCout_en;
input wire DRout_en;
input wire Zout_en;
input wire R2out_en;
input wire R1out_en;
input wire R0out_en;
input wire IRout_en;
output wire [15 : 0] bus_out;
output wire conflict;

  bus_mux16 inst (
    .PCout(PCout),
    .DRout(DRout),
    .Zout(Zout),
    .R2out(R2out),
    .R1out(R1out),
    .R0out(R0out),
    .IRout(IRout),
    .PCout_en(PCout_en),
    .DRout_en(DRout_en),
    .Zout_en(Zout_en),
    .R2out_en(R2out_en),
    .R1out_en(R1out_en),
    .R0out_en(R0out_en),
    .IRout_en(IRout_en),
    .bus_out(bus_out),
    .conflict(conflict)
  );
endmodule
