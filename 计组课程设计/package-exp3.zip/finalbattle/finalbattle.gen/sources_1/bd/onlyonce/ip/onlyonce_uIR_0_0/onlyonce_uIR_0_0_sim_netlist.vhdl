-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 17:16:30 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_uIR_0_0/onlyonce_uIR_0_0_sim_netlist.vhdl
-- Design      : onlyonce_uIR_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_uIR_0_0 is
  port (
    microIR : in STD_LOGIC_VECTOR ( 22 downto 0 );
    M : out STD_LOGIC;
    S : out STD_LOGIC_VECTOR ( 3 downto 0 );
    C0 : out STD_LOGIC;
    DREout_bit : out STD_LOGIC;
    out_sel : out STD_LOGIC_VECTOR ( 2 downto 0 );
    pc_ctrl : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Zin : out STD_LOGIC;
    DREin : out STD_LOGIC;
    in_sel : out STD_LOGIC_VECTOR ( 2 downto 0 );
    ram_op : out STD_LOGIC_VECTOR ( 1 downto 0 );
    G : out STD_LOGIC;
    tr_type : out STD_LOGIC_VECTOR ( 2 downto 0 );
    jp_addr : out STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_uIR_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_uIR_0_0 : entity is "onlyonce_uIR_0_0,uIR,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_uIR_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_uIR_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_uIR_0_0 : entity is "uIR,Vivado 2024.2";
end onlyonce_uIR_0_0;

architecture STRUCTURE of onlyonce_uIR_0_0 is
  signal \^microir\ : STD_LOGIC_VECTOR ( 22 downto 0 );
begin
  C0 <= \^microir\(17);
  DREin <= \^microir\(9);
  DREout_bit <= \^microir\(16);
  G <= \^microir\(3);
  M <= \^microir\(22);
  S(3 downto 0) <= \^microir\(21 downto 18);
  Zin <= \^microir\(10);
  \^microir\(22 downto 0) <= microIR(22 downto 0);
  in_sel(2 downto 0) <= \^microir\(8 downto 6);
  jp_addr(9 downto 0) <= \^microir\(17 downto 8);
  out_sel(2 downto 0) <= \^microir\(15 downto 13);
  pc_ctrl(1 downto 0) <= \^microir\(12 downto 11);
  ram_op(1 downto 0) <= \^microir\(5 downto 4);
  tr_type(2 downto 0) <= \^microir\(2 downto 0);
end STRUCTURE;
