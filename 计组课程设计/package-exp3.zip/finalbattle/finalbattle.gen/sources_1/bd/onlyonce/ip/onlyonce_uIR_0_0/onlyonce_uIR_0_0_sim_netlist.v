// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 11 17:16:30 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_uIR_0_0/onlyonce_uIR_0_0_sim_netlist.v
// Design      : onlyonce_uIR_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "onlyonce_uIR_0_0,uIR,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "uIR,Vivado 2024.2" *) 
(* NotValidForBitStream *)
module onlyonce_uIR_0_0
   (microIR,
    M,
    S,
    C0,
    DREout_bit,
    out_sel,
    pc_ctrl,
    Zin,
    DREin,
    in_sel,
    ram_op,
    G,
    tr_type,
    jp_addr);
  input [22:0]microIR;
  output M;
  output [3:0]S;
  output C0;
  output DREout_bit;
  output [2:0]out_sel;
  output [1:0]pc_ctrl;
  output Zin;
  output DREin;
  output [2:0]in_sel;
  output [1:0]ram_op;
  output G;
  output [2:0]tr_type;
  output [9:0]jp_addr;

  wire [22:0]microIR;

  assign C0 = microIR[17];
  assign DREin = microIR[9];
  assign DREout_bit = microIR[16];
  assign G = microIR[3];
  assign M = microIR[22];
  assign S[3:0] = microIR[21:18];
  assign Zin = microIR[10];
  assign in_sel[2:0] = microIR[8:6];
  assign jp_addr[9:0] = microIR[17:8];
  assign out_sel[2:0] = microIR[15:13];
  assign pc_ctrl[1:0] = microIR[12:11];
  assign ram_op[1:0] = microIR[5:4];
  assign tr_type[2:0] = microIR[2:0];
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
