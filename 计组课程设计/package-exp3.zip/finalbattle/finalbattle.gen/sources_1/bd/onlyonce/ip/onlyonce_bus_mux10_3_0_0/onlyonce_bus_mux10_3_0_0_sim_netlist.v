// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Wed Nov 12 19:24:51 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus_mux10_3_0_0/onlyonce_bus_mux10_3_0_0_sim_netlist.v
// Design      : onlyonce_bus_mux10_3_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "onlyonce_bus_mux10_3_0_0,bus_mux10_3,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "bus_mux10_3,Vivado 2024.2" *) 
(* NotValidForBitStream *)
module onlyonce_bus_mux10_3_0_0
   (in0,
    in1,
    in2,
    en0,
    en1,
    en2,
    bus_out,
    conflict);
  input [9:0]in0;
  input [9:0]in1;
  input [9:0]in2;
  input en0;
  input en1;
  input en2;
  output [9:0]bus_out;
  output conflict;

  wire [9:0]bus_out;
  wire conflict;
  wire en0;
  wire en1;
  wire en2;
  wire [9:0]in0;
  wire [9:0]in1;
  wire [9:0]in2;

  onlyonce_bus_mux10_3_0_0_bus_mux10_3 inst
       (.bus_out(bus_out),
        .conflict(conflict),
        .en0(en0),
        .en1(en1),
        .en2(en2),
        .in0(in0),
        .in1(in1),
        .in2(in2));
endmodule

(* ORIG_REF_NAME = "bus_mux10_3" *) 
module onlyonce_bus_mux10_3_0_0_bus_mux10_3
   (bus_out,
    conflict,
    en0,
    en2,
    en1,
    in0,
    in1,
    in2);
  output [9:0]bus_out;
  output conflict;
  input en0;
  input en2;
  input en1;
  input [9:0]in0;
  input [9:0]in1;
  input [9:0]in2;

  wire [9:0]bus_out;
  wire \bus_out[0]_INST_0_i_1_n_0 ;
  wire \bus_out[1]_INST_0_i_1_n_0 ;
  wire \bus_out[2]_INST_0_i_1_n_0 ;
  wire \bus_out[3]_INST_0_i_1_n_0 ;
  wire \bus_out[4]_INST_0_i_1_n_0 ;
  wire \bus_out[5]_INST_0_i_1_n_0 ;
  wire \bus_out[6]_INST_0_i_1_n_0 ;
  wire \bus_out[7]_INST_0_i_1_n_0 ;
  wire \bus_out[8]_INST_0_i_1_n_0 ;
  wire \bus_out[9]_INST_0_i_1_n_0 ;
  wire conflict;
  wire en0;
  wire en1;
  wire en2;
  wire [9:0]in0;
  wire [9:0]in1;
  wire [9:0]in2;

  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[0]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[0]_INST_0_i_1_n_0 ),
        .O(bus_out[0]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[0]_INST_0_i_1 
       (.I0(in0[0]),
        .I1(en0),
        .I2(in1[0]),
        .I3(en1),
        .I4(en2),
        .I5(in2[0]),
        .O(\bus_out[0]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[1]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[1]_INST_0_i_1_n_0 ),
        .O(bus_out[1]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[1]_INST_0_i_1 
       (.I0(in0[1]),
        .I1(en0),
        .I2(in1[1]),
        .I3(en1),
        .I4(en2),
        .I5(in2[1]),
        .O(\bus_out[1]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[2]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[2]_INST_0_i_1_n_0 ),
        .O(bus_out[2]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[2]_INST_0_i_1 
       (.I0(in0[2]),
        .I1(en0),
        .I2(in1[2]),
        .I3(en1),
        .I4(en2),
        .I5(in2[2]),
        .O(\bus_out[2]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[3]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[3]_INST_0_i_1_n_0 ),
        .O(bus_out[3]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[3]_INST_0_i_1 
       (.I0(in0[3]),
        .I1(en0),
        .I2(in1[3]),
        .I3(en1),
        .I4(en2),
        .I5(in2[3]),
        .O(\bus_out[3]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[4]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[4]_INST_0_i_1_n_0 ),
        .O(bus_out[4]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[4]_INST_0_i_1 
       (.I0(in0[4]),
        .I1(en0),
        .I2(in1[4]),
        .I3(en1),
        .I4(en2),
        .I5(in2[4]),
        .O(\bus_out[4]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[5]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[5]_INST_0_i_1_n_0 ),
        .O(bus_out[5]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[5]_INST_0_i_1 
       (.I0(in0[5]),
        .I1(en0),
        .I2(in1[5]),
        .I3(en1),
        .I4(en2),
        .I5(in2[5]),
        .O(\bus_out[5]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[6]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[6]_INST_0_i_1_n_0 ),
        .O(bus_out[6]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[6]_INST_0_i_1 
       (.I0(in0[6]),
        .I1(en0),
        .I2(in1[6]),
        .I3(en1),
        .I4(en2),
        .I5(in2[6]),
        .O(\bus_out[6]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[7]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[7]_INST_0_i_1_n_0 ),
        .O(bus_out[7]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[7]_INST_0_i_1 
       (.I0(in0[7]),
        .I1(en0),
        .I2(in1[7]),
        .I3(en1),
        .I4(en2),
        .I5(in2[7]),
        .O(\bus_out[7]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[8]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[8]_INST_0_i_1_n_0 ),
        .O(bus_out[8]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[8]_INST_0_i_1 
       (.I0(in0[8]),
        .I1(en0),
        .I2(in1[8]),
        .I3(en1),
        .I4(en2),
        .I5(in2[8]),
        .O(\bus_out[8]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h1600)) 
    \bus_out[9]_INST_0 
       (.I0(en0),
        .I1(en2),
        .I2(en1),
        .I3(\bus_out[9]_INST_0_i_1_n_0 ),
        .O(bus_out[9]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \bus_out[9]_INST_0_i_1 
       (.I0(in0[9]),
        .I1(en0),
        .I2(in1[9]),
        .I3(en1),
        .I4(en2),
        .I5(in2[9]),
        .O(\bus_out[9]_INST_0_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    sel_count
       (.I0(en1),
        .I1(en2),
        .I2(en0),
        .O(conflict));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
