-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Wed Nov 12 20:42:05 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_carry_lookahead_74182_0_0/onlyonce_carry_lookahead_74182_0_0_stub.vhdl
-- Design      : onlyonce_carry_lookahead_74182_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity onlyonce_carry_lookahead_74182_0_0 is
  Port ( 
    p : in STD_LOGIC_VECTOR ( 3 downto 0 );
    g : in STD_LOGIC_VECTOR ( 3 downto 0 );
    cin : in STD_LOGIC;
    cout : out STD_LOGIC_VECTOR ( 3 downto 0 );
    p_group : out STD_LOGIC;
    g_group : out STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_carry_lookahead_74182_0_0 : entity is "onlyonce_carry_lookahead_74182_0_0,carry_lookahead_74182,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of onlyonce_carry_lookahead_74182_0_0 : entity is "onlyonce_carry_lookahead_74182_0_0,carry_lookahead_74182,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=carry_lookahead_74182,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_carry_lookahead_74182_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_carry_lookahead_74182_0_0 : entity is "module_ref";
end onlyonce_carry_lookahead_74182_0_0;

architecture stub of onlyonce_carry_lookahead_74182_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "p[3:0],g[3:0],cin,cout[3:0],p_group,g_group";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "carry_lookahead_74182,Vivado 2024.2";
begin
end;
