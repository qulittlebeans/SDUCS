// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Wed Nov 12 19:24:52 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus_mux16_0_0/onlyonce_bus_mux16_0_0_stub.v
// Design      : onlyonce_bus_mux16_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_bus_mux16_0_0,bus_mux16,{}" *) (* CORE_GENERATION_INFO = "onlyonce_bus_mux16_0_0,bus_mux16,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bus_mux16,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "bus_mux16,Vivado 2024.2" *) 
module onlyonce_bus_mux16_0_0(PCout, DRout, Zout, R2out, R1out, R0out, IRout, 
  PCout_en, DRout_en, Zout_en, R2out_en, R1out_en, R0out_en, IRout_en, bus_out, conflict)
/* synthesis syn_black_box black_box_pad_pin="PCout[15:0],DRout[15:0],Zout[15:0],R2out[15:0],R1out[15:0],R0out[15:0],IRout[15:0],PCout_en,DRout_en,Zout_en,R2out_en,R1out_en,R0out_en,IRout_en,bus_out[15:0],conflict" */;
  input [15:0]PCout;
  input [15:0]DRout;
  input [15:0]Zout;
  input [15:0]R2out;
  input [15:0]R1out;
  input [15:0]R0out;
  input [15:0]IRout;
  input PCout_en;
  input DRout_en;
  input Zout_en;
  input R2out_en;
  input R1out_en;
  input R0out_en;
  input IRout_en;
  output [15:0]bus_out;
  output conflict;
endmodule
