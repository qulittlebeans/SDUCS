// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 11 17:21:38 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bits8_to_bus8_0_1/onlyonce_bits8_to_bus8_0_1_stub.v
// Design      : onlyonce_bits8_to_bus8_0_1
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_bits8_to_bus8_0_1,bits8_to_bus8,{}" *) (* CORE_GENERATION_INFO = "onlyonce_bits8_to_bus8_0_1,bits8_to_bus8,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bits8_to_bus8,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "bits8_to_bus8,Vivado 2024.2" *) 
module onlyonce_bits8_to_bus8_0_1(bit0, bit1, bit2, bit3, bit4, bit5, bit6, bit7, bus_out)
/* synthesis syn_black_box black_box_pad_pin="bit0,bit1,bit2,bit3,bit4,bit5,bit6,bit7,bus_out[7:0]" */;
  input bit0;
  input bit1;
  input bit2;
  input bit3;
  input bit4;
  input bit5;
  input bit6;
  input bit7;
  output [7:0]bus_out;
endmodule
