// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 11 17:15:31 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bits4_to_bus4_1_0/onlyonce_bits4_to_bus4_1_0_stub.v
// Design      : onlyonce_bits4_to_bus4_1_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_bits4_to_bus4_1_0,bits4_to_bus4,{}" *) (* CORE_GENERATION_INFO = "onlyonce_bits4_to_bus4_1_0,bits4_to_bus4,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bits4_to_bus4,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "bits4_to_bus4,Vivado 2024.2" *) 
module onlyonce_bits4_to_bus4_1_0(bit0, bit1, bit2, bit3, bus_out)
/* synthesis syn_black_box black_box_pad_pin="bit0,bit1,bit2,bit3,bus_out[3:0]" */;
  input bit0;
  input bit1;
  input bit2;
  input bit3;
  output [3:0]bus_out;
endmodule
