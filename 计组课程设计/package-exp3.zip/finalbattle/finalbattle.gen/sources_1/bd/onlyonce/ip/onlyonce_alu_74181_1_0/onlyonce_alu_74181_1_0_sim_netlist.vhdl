-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 18 15:00:54 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_alu_74181_1_0/onlyonce_alu_74181_1_0_sim_netlist.vhdl
-- Design      : onlyonce_alu_74181_1_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_alu_74181_1_0 is
  port (
    a : in STD_LOGIC_VECTOR ( 3 downto 0 );
    b : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s : in STD_LOGIC_VECTOR ( 3 downto 0 );
    m : in STD_LOGIC;
    cin : in STD_LOGIC;
    f : out STD_LOGIC_VECTOR ( 3 downto 0 );
    cout : out STD_LOGIC;
    zero : out STD_LOGIC;
    p : out STD_LOGIC;
    g : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_alu_74181_1_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_alu_74181_1_0 : entity is "onlyonce_alu_74181_1_0,alu_74181,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_alu_74181_1_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_alu_74181_1_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_alu_74181_1_0 : entity is "alu_74181,Vivado 2024.2";
end onlyonce_alu_74181_1_0;

architecture STRUCTURE of onlyonce_alu_74181_1_0 is
  signal cout_INST_0_i_1_n_0 : STD_LOGIC;
  signal cout_INST_0_i_2_n_0 : STD_LOGIC;
  signal \f[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \f[1]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \f[1]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \f[1]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \f[2]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \f[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \f[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \f[3]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \f[3]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \f[3]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \f[3]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal g_INST_0_i_1_n_0 : STD_LOGIC;
  signal zero_INST_0_i_1_n_0 : STD_LOGIC;
begin
cout_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000002B2BFF"
    )
        port map (
      I0 => \f[3]_INST_0_i_4_n_0\,
      I1 => \f[3]_INST_0_i_3_n_0\,
      I2 => \f[3]_INST_0_i_2_n_0\,
      I3 => cout_INST_0_i_1_n_0,
      I4 => cout_INST_0_i_2_n_0,
      I5 => m,
      O => cout
    );
cout_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"070F007F775F737F"
    )
        port map (
      I0 => s(0),
      I1 => s(1),
      I2 => s(3),
      I3 => s(2),
      I4 => b(3),
      I5 => a(3),
      O => cout_INST_0_i_1_n_0
    );
cout_INST_0_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00800800DFD5BBF3"
    )
        port map (
      I0 => s(0),
      I1 => s(1),
      I2 => s(2),
      I3 => s(3),
      I4 => b(3),
      I5 => a(3),
      O => cout_INST_0_i_2_n_0
    );
\f[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => m,
      I1 => cin,
      I2 => \f[0]_INST_0_i_1_n_0\,
      O => f(0)
    );
\f[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00F0F055553333"
    )
        port map (
      I0 => s(0),
      I1 => s(1),
      I2 => s(2),
      I3 => s(3),
      I4 => b(0),
      I5 => a(0),
      O => \f[0]_INST_0_i_1_n_0\
    );
\f[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00FF2BD4"
    )
        port map (
      I0 => \f[1]_INST_0_i_1_n_0\,
      I1 => \f[1]_INST_0_i_2_n_0\,
      I2 => cin,
      I3 => \f[1]_INST_0_i_3_n_0\,
      I4 => m,
      O => f(1)
    );
\f[1]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5D70115145445555"
    )
        port map (
      I0 => a(0),
      I1 => b(0),
      I2 => s(3),
      I3 => s(2),
      I4 => s(1),
      I5 => s(0),
      O => \f[1]_INST_0_i_1_n_0\
    );
\f[1]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAFCF200AA883200"
    )
        port map (
      I0 => a(0),
      I1 => b(0),
      I2 => s(1),
      I3 => s(2),
      I4 => s(3),
      I5 => s(0),
      O => \f[1]_INST_0_i_2_n_0\
    );
\f[1]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0055AAFFD8D8D8D8"
    )
        port map (
      I0 => b(1),
      I1 => s(0),
      I2 => s(1),
      I3 => s(2),
      I4 => s(3),
      I5 => a(1),
      O => \f[1]_INST_0_i_3_n_0\
    );
\f[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1E"
    )
        port map (
      I0 => m,
      I1 => \f[3]_INST_0_i_4_n_0\,
      I2 => \f[2]_INST_0_i_1_n_0\,
      O => f(2)
    );
\f[2]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5D7F4C6E193B082A"
    )
        port map (
      I0 => a(2),
      I1 => b(2),
      I2 => s(3),
      I3 => s(2),
      I4 => s(1),
      I5 => s(0),
      O => \f[2]_INST_0_i_1_n_0\
    );
\f[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"63336663"
    )
        port map (
      I0 => m,
      I1 => \f[3]_INST_0_i_1_n_0\,
      I2 => \f[3]_INST_0_i_2_n_0\,
      I3 => \f[3]_INST_0_i_3_n_0\,
      I4 => \f[3]_INST_0_i_4_n_0\,
      O => f(3)
    );
\f[3]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5D7F4C6E193B082A"
    )
        port map (
      I0 => a(3),
      I1 => b(3),
      I2 => s(3),
      I3 => s(2),
      I4 => s(1),
      I5 => s(0),
      O => \f[3]_INST_0_i_1_n_0\
    );
\f[3]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00800800DFD5BBF3"
    )
        port map (
      I0 => s(0),
      I1 => s(1),
      I2 => s(2),
      I3 => s(3),
      I4 => b(2),
      I5 => a(2),
      O => \f[3]_INST_0_i_2_n_0\
    );
\f[3]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"031B1B1B03DFFBFF"
    )
        port map (
      I0 => b(2),
      I1 => s(2),
      I2 => s(3),
      I3 => s(1),
      I4 => s(0),
      I5 => a(2),
      O => \f[3]_INST_0_i_3_n_0\
    );
\f[3]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"008E8EFF"
    )
        port map (
      I0 => cin,
      I1 => \f[1]_INST_0_i_2_n_0\,
      I2 => \f[1]_INST_0_i_1_n_0\,
      I3 => \f[3]_INST_0_i_5_n_0\,
      I4 => \f[3]_INST_0_i_6_n_0\,
      O => \f[3]_INST_0_i_4_n_0\
    );
\f[3]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"740455555C551055"
    )
        port map (
      I0 => a(1),
      I1 => s(3),
      I2 => s(2),
      I3 => s(1),
      I4 => s(0),
      I5 => b(1),
      O => \f[3]_INST_0_i_5_n_0\
    );
\f[3]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"031B1B1B03DFFBFF"
    )
        port map (
      I0 => b(1),
      I1 => s(2),
      I2 => s(3),
      I3 => s(1),
      I4 => s(0),
      I5 => a(1),
      O => \f[3]_INST_0_i_6_n_0\
    );
g_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0317173F"
    )
        port map (
      I0 => g_INST_0_i_1_n_0,
      I1 => cout_INST_0_i_1_n_0,
      I2 => cout_INST_0_i_2_n_0,
      I3 => \f[3]_INST_0_i_2_n_0\,
      I4 => \f[3]_INST_0_i_3_n_0\,
      O => g
    );
g_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF35FF35FF0000"
    )
        port map (
      I0 => s(2),
      I1 => s(3),
      I2 => b(0),
      I3 => a(0),
      I4 => \f[3]_INST_0_i_6_n_0\,
      I5 => \f[3]_INST_0_i_5_n_0\,
      O => g_INST_0_i_1_n_0
    );
p_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => \f[2]_INST_0_i_1_n_0\,
      I1 => \f[3]_INST_0_i_1_n_0\,
      I2 => \f[1]_INST_0_i_3_n_0\,
      I3 => \f[0]_INST_0_i_1_n_0\,
      O => p
    );
zero_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0550000004411000"
    )
        port map (
      I0 => zero_INST_0_i_1_n_0,
      I1 => \f[3]_INST_0_i_4_n_0\,
      I2 => \f[3]_INST_0_i_3_n_0\,
      I3 => \f[3]_INST_0_i_2_n_0\,
      I4 => \f[3]_INST_0_i_1_n_0\,
      I5 => m,
      O => zero
    );
zero_INST_0_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7D7D7DE7"
    )
        port map (
      I0 => \f[1]_INST_0_i_3_n_0\,
      I1 => \f[1]_INST_0_i_2_n_0\,
      I2 => \f[1]_INST_0_i_1_n_0\,
      I3 => cin,
      I4 => m,
      O => zero_INST_0_i_1_n_0
    );
end STRUCTURE;
