-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 19:42:41 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bits10_to_bus10_0_0/onlyonce_bits10_to_bus10_0_0_stub.vhdl
-- Design      : onlyonce_bits10_to_bus10_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity onlyonce_bits10_to_bus10_0_0 is
  Port ( 
    bit0 : in STD_LOGIC;
    bit1 : in STD_LOGIC;
    bit2 : in STD_LOGIC;
    bit3 : in STD_LOGIC;
    bit4 : in STD_LOGIC;
    bit5 : in STD_LOGIC;
    bit6 : in STD_LOGIC;
    bit7 : in STD_LOGIC;
    bit8 : in STD_LOGIC;
    bit9 : in STD_LOGIC;
    bus_out : out STD_LOGIC_VECTOR ( 9 downto 0 )
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bits10_to_bus10_0_0 : entity is "onlyonce_bits10_to_bus10_0_0,bits10_to_bus10,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of onlyonce_bits10_to_bus10_0_0 : entity is "onlyonce_bits10_to_bus10_0_0,bits10_to_bus10,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bits10_to_bus10,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bits10_to_bus10_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bits10_to_bus10_0_0 : entity is "module_ref";
end onlyonce_bits10_to_bus10_0_0;

architecture stub of onlyonce_bits10_to_bus10_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "bit0,bit1,bit2,bit3,bit4,bit5,bit6,bit7,bit8,bit9,bus_out[9:0]";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "bits10_to_bus10,Vivado 2024.2";
begin
end;
