-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Wed Nov 12 20:42:05 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_carry_lookahead_74182_0_0/onlyonce_carry_lookahead_74182_0_0_sim_netlist.vhdl
-- Design      : onlyonce_carry_lookahead_74182_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_carry_lookahead_74182_0_0 is
  port (
    p : in STD_LOGIC_VECTOR ( 3 downto 0 );
    g : in STD_LOGIC_VECTOR ( 3 downto 0 );
    cin : in STD_LOGIC;
    cout : out STD_LOGIC_VECTOR ( 3 downto 0 );
    p_group : out STD_LOGIC;
    g_group : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_carry_lookahead_74182_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_carry_lookahead_74182_0_0 : entity is "onlyonce_carry_lookahead_74182_0_0,carry_lookahead_74182,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_carry_lookahead_74182_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_carry_lookahead_74182_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_carry_lookahead_74182_0_0 : entity is "carry_lookahead_74182,Vivado 2024.2";
end onlyonce_carry_lookahead_74182_0_0;

architecture STRUCTURE of onlyonce_carry_lookahead_74182_0_0 is
  signal \^cout\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \inst/cout1__0\ : STD_LOGIC;
  signal \inst/cout2__0\ : STD_LOGIC;
begin
  cout(3 downto 0) <= \^cout\(3 downto 0);
  g_group <= \^cout\(3);
\cout[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => g(0),
      I1 => p(0),
      I2 => cin,
      O => \^cout\(0)
    );
\cout[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FAEAEAEA"
    )
        port map (
      I0 => g(1),
      I1 => g(0),
      I2 => p(1),
      I3 => p(0),
      I4 => cin,
      O => \^cout\(1)
    );
\cout[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFCCFECCFCCCFCCC"
    )
        port map (
      I0 => \inst/cout1__0\,
      I1 => g(2),
      I2 => g(1),
      I3 => p(2),
      I4 => g(0),
      I5 => p(1),
      O => \^cout\(2)
    );
\cout[2]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => cin,
      I1 => p(0),
      O => \inst/cout1__0\
    );
g_group_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCFCFCECFCCCFCCC"
    )
        port map (
      I0 => \inst/cout2__0\,
      I1 => g(3),
      I2 => p(3),
      I3 => g(2),
      I4 => g(1),
      I5 => p(2),
      O => \^cout\(3)
    );
g_group_INST_0_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => g(0),
      I1 => p(1),
      O => \inst/cout2__0\
    );
p_group_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => p(2),
      I1 => p(3),
      I2 => p(1),
      I3 => p(0),
      O => p_group
    );
end STRUCTURE;
