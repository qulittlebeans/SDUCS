// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Wed Nov 12 12:28:07 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_rom_1kx23_0_1/onlyonce_rom_1kx23_0_1_sim_netlist.v
// Design      : onlyonce_rom_1kx23_0_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "onlyonce_rom_1kx23_0_1,rom_1kx23,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "rom_1kx23,Vivado 2024.2" *) 
(* NotValidForBitStream *)
module onlyonce_rom_1kx23_0_1
   (clk,
    en,
    addr,
    data_out);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input clk;
  input en;
  input [9:0]addr;
  output [22:0]data_out;

  wire [9:0]addr;
  wire clk;
  wire [22:0]data_out;
  wire \data_out[22]_INST_0_i_1_n_0 ;
  wire en;

  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \data_out[12]_INST_0 
       (.I0(1'b0),
        .I1(\data_out[22]_INST_0_i_1_n_0 ),
        .I2(1'b0),
        .I3(1'b0),
        .I4(1'b0),
        .I5(1'b0),
        .O(data_out[12]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \data_out[19]_INST_0 
       (.I0(1'b0),
        .I1(\data_out[22]_INST_0_i_1_n_0 ),
        .I2(1'b0),
        .I3(1'b0),
        .I4(1'b0),
        .I5(1'b0),
        .O(data_out[19]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \data_out[20]_INST_0 
       (.I0(1'b0),
        .I1(\data_out[22]_INST_0_i_1_n_0 ),
        .I2(1'b0),
        .I3(1'b0),
        .I4(1'b0),
        .I5(1'b0),
        .O(data_out[20]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \data_out[22]_INST_0 
       (.I0(1'b0),
        .I1(\data_out[22]_INST_0_i_1_n_0 ),
        .I2(1'b0),
        .I3(1'b0),
        .I4(1'b0),
        .I5(1'b0),
        .O(data_out[22]));
  FDRE #(
    .INIT(1'b1)) 
    \data_out[22]_INST_0_i_1 
       (.C(clk),
        .CE(1'b1),
        .D(en),
        .Q(\data_out[22]_INST_0_i_1_n_0 ),
        .R(1'b0));
  onlyonce_rom_1kx23_0_1_rom_1kx23 inst
       (.addr(addr[6:0]),
        .clk(clk),
        .data_out({data_out[21],data_out[18:13],data_out[11:0]}),
        .data_out_0_sp_1(\data_out[22]_INST_0_i_1_n_0 ));
endmodule

(* ORIG_REF_NAME = "rom_1kx23" *) 
module onlyonce_rom_1kx23_0_1_rom_1kx23
   (data_out,
    addr,
    data_out_0_sp_1,
    clk);
  output [18:0]data_out;
  input [6:0]addr;
  input data_out_0_sp_1;
  input clk;

  wire [6:0]addr;
  wire clk;
  wire [18:0]data_out;
  wire data_out_0_sn_1;
  wire \data_out_tristate_oe[0]_i_1_n_0 ;
  wire \data_out_tristate_oe[11]_i_1_n_0 ;
  wire \data_out_tristate_oe[13]_i_1_n_0 ;
  wire \data_out_tristate_oe[13]_i_2_n_0 ;
  wire \data_out_tristate_oe[14]_i_1_n_0 ;
  wire \data_out_tristate_oe[15]_i_1_n_0 ;
  wire \data_out_tristate_oe[16]_i_1_n_0 ;
  wire \data_out_tristate_oe[1]_i_1_n_0 ;
  wire \data_out_tristate_oe[21]_i_1_n_0 ;
  wire \data_out_tristate_oe[21]_i_2_n_0 ;
  wire \data_out_tristate_oe[2]_i_1_n_0 ;
  wire \data_out_tristate_oe[3]_i_1_n_0 ;
  wire \data_out_tristate_oe[6]_i_1_n_0 ;
  wire \data_out_tristate_oe[7]_i_1_n_0 ;
  wire \data_out_tristate_oe[8]_i_1_n_0 ;
  wire \data_out_tristate_oe[8]_i_2_n_0 ;
  wire \data_out_tristate_oe[9]_i_1_n_0 ;
  wire \data_out_tristate_oe_reg_n_0_[0] ;
  wire \data_out_tristate_oe_reg_n_0_[11] ;
  wire \data_out_tristate_oe_reg_n_0_[13] ;
  wire \data_out_tristate_oe_reg_n_0_[14] ;
  wire \data_out_tristate_oe_reg_n_0_[15] ;
  wire \data_out_tristate_oe_reg_n_0_[16] ;
  wire \data_out_tristate_oe_reg_n_0_[1] ;
  wire \data_out_tristate_oe_reg_n_0_[21] ;
  wire \data_out_tristate_oe_reg_n_0_[2] ;
  wire \data_out_tristate_oe_reg_n_0_[3] ;
  wire \data_out_tristate_oe_reg_n_0_[6] ;
  wire \data_out_tristate_oe_reg_n_0_[7] ;
  wire \data_out_tristate_oe_reg_n_0_[8] ;
  wire \data_out_tristate_oe_reg_n_0_[9] ;

  assign data_out_0_sn_1 = data_out_0_sp_1;
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[0]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[0] ),
        .I1(data_out_0_sn_1),
        .O(data_out[0]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[10]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[21] ),
        .I1(data_out_0_sn_1),
        .O(data_out[10]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[11]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[11] ),
        .I1(data_out_0_sn_1),
        .O(data_out[11]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[13]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[13] ),
        .I1(data_out_0_sn_1),
        .O(data_out[12]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[14]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[14] ),
        .I1(data_out_0_sn_1),
        .O(data_out[13]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[15]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[15] ),
        .I1(data_out_0_sn_1),
        .O(data_out[14]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[16]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[16] ),
        .I1(data_out_0_sn_1),
        .O(data_out[15]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[17]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[21] ),
        .I1(data_out_0_sn_1),
        .O(data_out[16]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[18]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[21] ),
        .I1(data_out_0_sn_1),
        .O(data_out[17]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[1]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[1] ),
        .I1(data_out_0_sn_1),
        .O(data_out[1]));
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[21]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[21] ),
        .I1(data_out_0_sn_1),
        .O(data_out[18]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[2]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[2] ),
        .I1(data_out_0_sn_1),
        .O(data_out[2]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[3]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[3] ),
        .I1(data_out_0_sn_1),
        .O(data_out[3]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[4]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[9] ),
        .I1(data_out_0_sn_1),
        .O(data_out[4]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[5]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[16] ),
        .I1(data_out_0_sn_1),
        .O(data_out[5]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[6]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[6] ),
        .I1(data_out_0_sn_1),
        .O(data_out[6]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[7]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[7] ),
        .I1(data_out_0_sn_1),
        .O(data_out[7]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[8]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[8] ),
        .I1(data_out_0_sn_1),
        .O(data_out[8]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \data_out[9]_INST_0 
       (.I0(\data_out_tristate_oe_reg_n_0_[9] ),
        .I1(data_out_0_sn_1),
        .O(data_out[9]));
  LUT6 #(
    .INIT(64'h3B3B003B3BBB0BBB)) 
    \data_out_tristate_oe[0]_i_1 
       (.I0(\data_out_tristate_oe[13]_i_2_n_0 ),
        .I1(addr[0]),
        .I2(addr[1]),
        .I3(addr[4]),
        .I4(addr[5]),
        .I5(addr[6]),
        .O(\data_out_tristate_oe[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000015)) 
    \data_out_tristate_oe[11]_i_1 
       (.I0(addr[6]),
        .I1(addr[4]),
        .I2(addr[5]),
        .I3(addr[2]),
        .I4(addr[3]),
        .I5(addr[1]),
        .O(\data_out_tristate_oe[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h2200000062101010)) 
    \data_out_tristate_oe[13]_i_1 
       (.I0(addr[0]),
        .I1(addr[1]),
        .I2(\data_out_tristate_oe[13]_i_2_n_0 ),
        .I3(addr[5]),
        .I4(addr[4]),
        .I5(addr[6]),
        .O(\data_out_tristate_oe[13]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \data_out_tristate_oe[13]_i_2 
       (.I0(addr[2]),
        .I1(addr[3]),
        .O(\data_out_tristate_oe[13]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h32223155)) 
    \data_out_tristate_oe[14]_i_1 
       (.I0(addr[0]),
        .I1(addr[1]),
        .I2(addr[5]),
        .I3(addr[4]),
        .I4(addr[6]),
        .O(\data_out_tristate_oe[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h0000CD57)) 
    \data_out_tristate_oe[15]_i_1 
       (.I0(addr[4]),
        .I1(addr[5]),
        .I2(addr[6]),
        .I3(addr[1]),
        .I4(addr[0]),
        .O(\data_out_tristate_oe[15]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h08)) 
    \data_out_tristate_oe[16]_i_1 
       (.I0(addr[1]),
        .I1(addr[6]),
        .I2(addr[0]),
        .O(\data_out_tristate_oe[16]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hBFBFBFB0)) 
    \data_out_tristate_oe[1]_i_1 
       (.I0(addr[4]),
        .I1(addr[5]),
        .I2(addr[1]),
        .I3(addr[3]),
        .I4(addr[2]),
        .O(\data_out_tristate_oe[1]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \data_out_tristate_oe[21]_i_1 
       (.I0(addr[0]),
        .O(\data_out_tristate_oe[21]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h08)) 
    \data_out_tristate_oe[21]_i_2 
       (.I0(addr[5]),
        .I1(addr[4]),
        .I2(addr[1]),
        .O(\data_out_tristate_oe[21]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \data_out_tristate_oe[2]_i_1 
       (.I0(addr[5]),
        .I1(addr[4]),
        .I2(addr[1]),
        .O(\data_out_tristate_oe[2]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \data_out_tristate_oe[3]_i_1 
       (.I0(addr[4]),
        .I1(addr[6]),
        .O(\data_out_tristate_oe[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h2222222215100504)) 
    \data_out_tristate_oe[6]_i_1 
       (.I0(addr[0]),
        .I1(addr[1]),
        .I2(addr[4]),
        .I3(addr[2]),
        .I4(addr[5]),
        .I5(addr[6]),
        .O(\data_out_tristate_oe[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h4455000044552131)) 
    \data_out_tristate_oe[7]_i_1 
       (.I0(addr[0]),
        .I1(addr[1]),
        .I2(addr[6]),
        .I3(addr[4]),
        .I4(addr[5]),
        .I5(addr[2]),
        .O(\data_out_tristate_oe[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000F0545000F0000)) 
    \data_out_tristate_oe[8]_i_1 
       (.I0(addr[0]),
        .I1(addr[5]),
        .I2(addr[1]),
        .I3(addr[4]),
        .I4(addr[6]),
        .I5(\data_out_tristate_oe[8]_i_2_n_0 ),
        .O(\data_out_tristate_oe[8]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \data_out_tristate_oe[8]_i_2 
       (.I0(addr[3]),
        .I1(addr[2]),
        .O(\data_out_tristate_oe[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000030301)) 
    \data_out_tristate_oe[9]_i_1 
       (.I0(addr[1]),
        .I1(addr[3]),
        .I2(addr[2]),
        .I3(addr[5]),
        .I4(addr[4]),
        .I5(addr[6]),
        .O(\data_out_tristate_oe[9]_i_1_n_0 ));
  FDRE \data_out_tristate_oe_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[0]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[11]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[11] ),
        .R(\data_out_tristate_oe[21]_i_1_n_0 ));
  FDRE \data_out_tristate_oe_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[13]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[13] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[14] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[14]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[14] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[15] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[15]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[15] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[16] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[16]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[16] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[1]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[1] ),
        .R(\data_out_tristate_oe[21]_i_1_n_0 ));
  FDRE \data_out_tristate_oe_reg[21] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[21]_i_2_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[21] ),
        .R(\data_out_tristate_oe[21]_i_1_n_0 ));
  FDRE \data_out_tristate_oe_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[2]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[3]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[6]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[7]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[7] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[8]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[8] ),
        .R(1'b0));
  FDRE \data_out_tristate_oe_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(\data_out_tristate_oe[9]_i_1_n_0 ),
        .Q(\data_out_tristate_oe_reg_n_0_[9] ),
        .R(\data_out_tristate_oe[21]_i_1_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
