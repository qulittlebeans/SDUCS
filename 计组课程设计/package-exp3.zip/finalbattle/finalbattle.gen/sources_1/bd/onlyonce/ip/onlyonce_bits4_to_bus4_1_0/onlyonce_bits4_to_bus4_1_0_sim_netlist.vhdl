-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 17:15:31 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bits4_to_bus4_1_0/onlyonce_bits4_to_bus4_1_0_sim_netlist.vhdl
-- Design      : onlyonce_bits4_to_bus4_1_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_bits4_to_bus4_1_0 is
  port (
    bit0 : in STD_LOGIC;
    bit1 : in STD_LOGIC;
    bit2 : in STD_LOGIC;
    bit3 : in STD_LOGIC;
    bus_out : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_bits4_to_bus4_1_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bits4_to_bus4_1_0 : entity is "onlyonce_bits4_to_bus4_1_0,bits4_to_bus4,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bits4_to_bus4_1_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bits4_to_bus4_1_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_bits4_to_bus4_1_0 : entity is "bits4_to_bus4,Vivado 2024.2";
end onlyonce_bits4_to_bus4_1_0;

architecture STRUCTURE of onlyonce_bits4_to_bus4_1_0 is
  signal \^bit0\ : STD_LOGIC;
  signal \^bit1\ : STD_LOGIC;
  signal \^bit2\ : STD_LOGIC;
  signal \^bit3\ : STD_LOGIC;
begin
  \^bit0\ <= bit0;
  \^bit1\ <= bit1;
  \^bit2\ <= bit2;
  \^bit3\ <= bit3;
  bus_out(3) <= \^bit3\;
  bus_out(2) <= \^bit2\;
  bus_out(1) <= \^bit1\;
  bus_out(0) <= \^bit0\;
end STRUCTURE;
