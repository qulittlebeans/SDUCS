-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 17:21:38 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bits8_to_bus8_0_1/onlyonce_bits8_to_bus8_0_1_sim_netlist.vhdl
-- Design      : onlyonce_bits8_to_bus8_0_1
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_bits8_to_bus8_0_1 is
  port (
    bit0 : in STD_LOGIC;
    bit1 : in STD_LOGIC;
    bit2 : in STD_LOGIC;
    bit3 : in STD_LOGIC;
    bit4 : in STD_LOGIC;
    bit5 : in STD_LOGIC;
    bit6 : in STD_LOGIC;
    bit7 : in STD_LOGIC;
    bus_out : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_bits8_to_bus8_0_1 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bits8_to_bus8_0_1 : entity is "onlyonce_bits8_to_bus8_0_1,bits8_to_bus8,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bits8_to_bus8_0_1 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bits8_to_bus8_0_1 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_bits8_to_bus8_0_1 : entity is "bits8_to_bus8,Vivado 2024.2";
end onlyonce_bits8_to_bus8_0_1;

architecture STRUCTURE of onlyonce_bits8_to_bus8_0_1 is
  signal \^bit0\ : STD_LOGIC;
  signal \^bit1\ : STD_LOGIC;
  signal \^bit2\ : STD_LOGIC;
  signal \^bit3\ : STD_LOGIC;
  signal \^bit4\ : STD_LOGIC;
  signal \^bit5\ : STD_LOGIC;
  signal \^bit6\ : STD_LOGIC;
  signal \^bit7\ : STD_LOGIC;
begin
  \^bit0\ <= bit0;
  \^bit1\ <= bit1;
  \^bit2\ <= bit2;
  \^bit3\ <= bit3;
  \^bit4\ <= bit4;
  \^bit5\ <= bit5;
  \^bit6\ <= bit6;
  \^bit7\ <= bit7;
  bus_out(7) <= \^bit7\;
  bus_out(6) <= \^bit6\;
  bus_out(5) <= \^bit5\;
  bus_out(4) <= \^bit4\;
  bus_out(3) <= \^bit3\;
  bus_out(2) <= \^bit2\;
  bus_out(1) <= \^bit1\;
  bus_out(0) <= \^bit0\;
end STRUCTURE;
