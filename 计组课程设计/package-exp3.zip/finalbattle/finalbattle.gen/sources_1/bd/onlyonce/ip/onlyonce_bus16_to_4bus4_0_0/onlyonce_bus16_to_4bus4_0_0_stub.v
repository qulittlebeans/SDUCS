// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 11 17:18:23 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus16_to_4bus4_0_0/onlyonce_bus16_to_4bus4_0_0_stub.v
// Design      : onlyonce_bus16_to_4bus4_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_bus16_to_4bus4_0_0,bus16_to_4bus4,{}" *) (* CORE_GENERATION_INFO = "onlyonce_bus16_to_4bus4_0_0,bus16_to_4bus4,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bus16_to_4bus4,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "bus16_to_4bus4,Vivado 2024.2" *) 
module onlyonce_bus16_to_4bus4_0_0(bus_in, bus_out0, bus_out1, bus_out2, bus_out3)
/* synthesis syn_black_box black_box_pad_pin="bus_in[15:0],bus_out0[3:0],bus_out1[3:0],bus_out2[3:0],bus_out3[3:0]" */;
  input [15:0]bus_in;
  output [3:0]bus_out0;
  output [3:0]bus_out1;
  output [3:0]bus_out2;
  output [3:0]bus_out3;
endmodule
