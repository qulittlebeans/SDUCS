-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Wed Nov 12 19:24:51 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus_mux10_3_0_0/onlyonce_bus_mux10_3_0_0_sim_netlist.vhdl
-- Design      : onlyonce_bus_mux10_3_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_bus_mux10_3_0_0_bus_mux10_3 is
  port (
    bus_out : out STD_LOGIC_VECTOR ( 9 downto 0 );
    conflict : out STD_LOGIC;
    en0 : in STD_LOGIC;
    en2 : in STD_LOGIC;
    en1 : in STD_LOGIC;
    in0 : in STD_LOGIC_VECTOR ( 9 downto 0 );
    in1 : in STD_LOGIC_VECTOR ( 9 downto 0 );
    in2 : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of onlyonce_bus_mux10_3_0_0_bus_mux10_3 : entity is "bus_mux10_3";
end onlyonce_bus_mux10_3_0_0_bus_mux10_3;

architecture STRUCTURE of onlyonce_bus_mux10_3_0_0_bus_mux10_3 is
  signal \bus_out[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[1]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[2]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[6]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[9]_INST_0_i_1_n_0\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \bus_out[0]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bus_out[1]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bus_out[2]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bus_out[3]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bus_out[4]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bus_out[5]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bus_out[6]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bus_out[7]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bus_out[8]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bus_out[9]_INST_0\ : label is "soft_lutpair0";
begin
\bus_out[0]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[0]_INST_0_i_1_n_0\,
      O => bus_out(0)
    );
\bus_out[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(0),
      I1 => en0,
      I2 => in1(0),
      I3 => en1,
      I4 => en2,
      I5 => in2(0),
      O => \bus_out[0]_INST_0_i_1_n_0\
    );
\bus_out[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[1]_INST_0_i_1_n_0\,
      O => bus_out(1)
    );
\bus_out[1]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(1),
      I1 => en0,
      I2 => in1(1),
      I3 => en1,
      I4 => en2,
      I5 => in2(1),
      O => \bus_out[1]_INST_0_i_1_n_0\
    );
\bus_out[2]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[2]_INST_0_i_1_n_0\,
      O => bus_out(2)
    );
\bus_out[2]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(2),
      I1 => en0,
      I2 => in1(2),
      I3 => en1,
      I4 => en2,
      I5 => in2(2),
      O => \bus_out[2]_INST_0_i_1_n_0\
    );
\bus_out[3]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[3]_INST_0_i_1_n_0\,
      O => bus_out(3)
    );
\bus_out[3]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(3),
      I1 => en0,
      I2 => in1(3),
      I3 => en1,
      I4 => en2,
      I5 => in2(3),
      O => \bus_out[3]_INST_0_i_1_n_0\
    );
\bus_out[4]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[4]_INST_0_i_1_n_0\,
      O => bus_out(4)
    );
\bus_out[4]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(4),
      I1 => en0,
      I2 => in1(4),
      I3 => en1,
      I4 => en2,
      I5 => in2(4),
      O => \bus_out[4]_INST_0_i_1_n_0\
    );
\bus_out[5]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[5]_INST_0_i_1_n_0\,
      O => bus_out(5)
    );
\bus_out[5]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(5),
      I1 => en0,
      I2 => in1(5),
      I3 => en1,
      I4 => en2,
      I5 => in2(5),
      O => \bus_out[5]_INST_0_i_1_n_0\
    );
\bus_out[6]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[6]_INST_0_i_1_n_0\,
      O => bus_out(6)
    );
\bus_out[6]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(6),
      I1 => en0,
      I2 => in1(6),
      I3 => en1,
      I4 => en2,
      I5 => in2(6),
      O => \bus_out[6]_INST_0_i_1_n_0\
    );
\bus_out[7]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[7]_INST_0_i_1_n_0\,
      O => bus_out(7)
    );
\bus_out[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(7),
      I1 => en0,
      I2 => in1(7),
      I3 => en1,
      I4 => en2,
      I5 => in2(7),
      O => \bus_out[7]_INST_0_i_1_n_0\
    );
\bus_out[8]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[8]_INST_0_i_1_n_0\,
      O => bus_out(8)
    );
\bus_out[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(8),
      I1 => en0,
      I2 => in1(8),
      I3 => en1,
      I4 => en2,
      I5 => in2(8),
      O => \bus_out[8]_INST_0_i_1_n_0\
    );
\bus_out[9]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1600"
    )
        port map (
      I0 => en0,
      I1 => en2,
      I2 => en1,
      I3 => \bus_out[9]_INST_0_i_1_n_0\,
      O => bus_out(9)
    );
\bus_out[9]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => in0(9),
      I1 => en0,
      I2 => in1(9),
      I3 => en1,
      I4 => en2,
      I5 => in2(9),
      O => \bus_out[9]_INST_0_i_1_n_0\
    );
sel_count: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E8"
    )
        port map (
      I0 => en1,
      I1 => en2,
      I2 => en0,
      O => conflict
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_bus_mux10_3_0_0 is
  port (
    in0 : in STD_LOGIC_VECTOR ( 9 downto 0 );
    in1 : in STD_LOGIC_VECTOR ( 9 downto 0 );
    in2 : in STD_LOGIC_VECTOR ( 9 downto 0 );
    en0 : in STD_LOGIC;
    en1 : in STD_LOGIC;
    en2 : in STD_LOGIC;
    bus_out : out STD_LOGIC_VECTOR ( 9 downto 0 );
    conflict : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_bus_mux10_3_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bus_mux10_3_0_0 : entity is "onlyonce_bus_mux10_3_0_0,bus_mux10_3,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bus_mux10_3_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bus_mux10_3_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_bus_mux10_3_0_0 : entity is "bus_mux10_3,Vivado 2024.2";
end onlyonce_bus_mux10_3_0_0;

architecture STRUCTURE of onlyonce_bus_mux10_3_0_0 is
begin
inst: entity work.onlyonce_bus_mux10_3_0_0_bus_mux10_3
     port map (
      bus_out(9 downto 0) => bus_out(9 downto 0),
      conflict => conflict,
      en0 => en0,
      en1 => en1,
      en2 => en2,
      in0(9 downto 0) => in0(9 downto 0),
      in1(9 downto 0) => in1(9 downto 0),
      in2(9 downto 0) => in2(9 downto 0)
    );
end STRUCTURE;
