// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 18 15:00:54 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_alu_74181_2_0/onlyonce_alu_74181_2_0_sim_netlist.v
// Design      : onlyonce_alu_74181_2_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "onlyonce_alu_74181_2_0,alu_74181,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "alu_74181,Vivado 2024.2" *) 
(* NotValidForBitStream *)
module onlyonce_alu_74181_2_0
   (a,
    b,
    s,
    m,
    cin,
    f,
    cout,
    zero,
    p,
    g);
  input [3:0]a;
  input [3:0]b;
  input [3:0]s;
  input m;
  input cin;
  output [3:0]f;
  output cout;
  output zero;
  output p;
  output g;

  wire [3:0]a;
  wire [3:0]b;
  wire cin;
  wire cout;
  wire cout_INST_0_i_1_n_0;
  wire cout_INST_0_i_2_n_0;
  wire [3:0]f;
  wire \f[0]_INST_0_i_1_n_0 ;
  wire \f[1]_INST_0_i_1_n_0 ;
  wire \f[1]_INST_0_i_2_n_0 ;
  wire \f[1]_INST_0_i_3_n_0 ;
  wire \f[2]_INST_0_i_1_n_0 ;
  wire \f[3]_INST_0_i_1_n_0 ;
  wire \f[3]_INST_0_i_2_n_0 ;
  wire \f[3]_INST_0_i_3_n_0 ;
  wire \f[3]_INST_0_i_4_n_0 ;
  wire \f[3]_INST_0_i_5_n_0 ;
  wire \f[3]_INST_0_i_6_n_0 ;
  wire g;
  wire g_INST_0_i_1_n_0;
  wire m;
  wire p;
  wire [3:0]s;
  wire zero;
  wire zero_INST_0_i_1_n_0;

  LUT6 #(
    .INIT(64'h00000000002B2BFF)) 
    cout_INST_0
       (.I0(\f[3]_INST_0_i_4_n_0 ),
        .I1(\f[3]_INST_0_i_3_n_0 ),
        .I2(\f[3]_INST_0_i_2_n_0 ),
        .I3(cout_INST_0_i_1_n_0),
        .I4(cout_INST_0_i_2_n_0),
        .I5(m),
        .O(cout));
  LUT6 #(
    .INIT(64'h070F007F775F737F)) 
    cout_INST_0_i_1
       (.I0(s[0]),
        .I1(s[1]),
        .I2(s[3]),
        .I3(s[2]),
        .I4(b[3]),
        .I5(a[3]),
        .O(cout_INST_0_i_1_n_0));
  LUT6 #(
    .INIT(64'h00800800DFD5BBF3)) 
    cout_INST_0_i_2
       (.I0(s[0]),
        .I1(s[1]),
        .I2(s[2]),
        .I3(s[3]),
        .I4(b[3]),
        .I5(a[3]),
        .O(cout_INST_0_i_2_n_0));
  LUT3 #(
    .INIT(8'hE1)) 
    \f[0]_INST_0 
       (.I0(m),
        .I1(cin),
        .I2(\f[0]_INST_0_i_1_n_0 ),
        .O(f[0]));
  LUT6 #(
    .INIT(64'hFF00F0F055553333)) 
    \f[0]_INST_0_i_1 
       (.I0(s[0]),
        .I1(s[1]),
        .I2(s[2]),
        .I3(s[3]),
        .I4(b[0]),
        .I5(a[0]),
        .O(\f[0]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00FF2BD4)) 
    \f[1]_INST_0 
       (.I0(\f[1]_INST_0_i_1_n_0 ),
        .I1(\f[1]_INST_0_i_2_n_0 ),
        .I2(cin),
        .I3(\f[1]_INST_0_i_3_n_0 ),
        .I4(m),
        .O(f[1]));
  LUT6 #(
    .INIT(64'h5D70115145445555)) 
    \f[1]_INST_0_i_1 
       (.I0(a[0]),
        .I1(b[0]),
        .I2(s[3]),
        .I3(s[2]),
        .I4(s[1]),
        .I5(s[0]),
        .O(\f[1]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFAFCF200AA883200)) 
    \f[1]_INST_0_i_2 
       (.I0(a[0]),
        .I1(b[0]),
        .I2(s[1]),
        .I3(s[2]),
        .I4(s[3]),
        .I5(s[0]),
        .O(\f[1]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0055AAFFD8D8D8D8)) 
    \f[1]_INST_0_i_3 
       (.I0(b[1]),
        .I1(s[0]),
        .I2(s[1]),
        .I3(s[2]),
        .I4(s[3]),
        .I5(a[1]),
        .O(\f[1]_INST_0_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h1E)) 
    \f[2]_INST_0 
       (.I0(m),
        .I1(\f[3]_INST_0_i_4_n_0 ),
        .I2(\f[2]_INST_0_i_1_n_0 ),
        .O(f[2]));
  LUT6 #(
    .INIT(64'h5D7F4C6E193B082A)) 
    \f[2]_INST_0_i_1 
       (.I0(a[2]),
        .I1(b[2]),
        .I2(s[3]),
        .I3(s[2]),
        .I4(s[1]),
        .I5(s[0]),
        .O(\f[2]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h63336663)) 
    \f[3]_INST_0 
       (.I0(m),
        .I1(\f[3]_INST_0_i_1_n_0 ),
        .I2(\f[3]_INST_0_i_2_n_0 ),
        .I3(\f[3]_INST_0_i_3_n_0 ),
        .I4(\f[3]_INST_0_i_4_n_0 ),
        .O(f[3]));
  LUT6 #(
    .INIT(64'h5D7F4C6E193B082A)) 
    \f[3]_INST_0_i_1 
       (.I0(a[3]),
        .I1(b[3]),
        .I2(s[3]),
        .I3(s[2]),
        .I4(s[1]),
        .I5(s[0]),
        .O(\f[3]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00800800DFD5BBF3)) 
    \f[3]_INST_0_i_2 
       (.I0(s[0]),
        .I1(s[1]),
        .I2(s[2]),
        .I3(s[3]),
        .I4(b[2]),
        .I5(a[2]),
        .O(\f[3]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h031B1B1B03DFFBFF)) 
    \f[3]_INST_0_i_3 
       (.I0(b[2]),
        .I1(s[2]),
        .I2(s[3]),
        .I3(s[1]),
        .I4(s[0]),
        .I5(a[2]),
        .O(\f[3]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h008E8EFF)) 
    \f[3]_INST_0_i_4 
       (.I0(cin),
        .I1(\f[1]_INST_0_i_2_n_0 ),
        .I2(\f[1]_INST_0_i_1_n_0 ),
        .I3(\f[3]_INST_0_i_5_n_0 ),
        .I4(\f[3]_INST_0_i_6_n_0 ),
        .O(\f[3]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h740455555C551055)) 
    \f[3]_INST_0_i_5 
       (.I0(a[1]),
        .I1(s[3]),
        .I2(s[2]),
        .I3(s[1]),
        .I4(s[0]),
        .I5(b[1]),
        .O(\f[3]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h031B1B1B03DFFBFF)) 
    \f[3]_INST_0_i_6 
       (.I0(b[1]),
        .I1(s[2]),
        .I2(s[3]),
        .I3(s[1]),
        .I4(s[0]),
        .I5(a[1]),
        .O(\f[3]_INST_0_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h0317173F)) 
    g_INST_0
       (.I0(g_INST_0_i_1_n_0),
        .I1(cout_INST_0_i_1_n_0),
        .I2(cout_INST_0_i_2_n_0),
        .I3(\f[3]_INST_0_i_2_n_0 ),
        .I4(\f[3]_INST_0_i_3_n_0 ),
        .O(g));
  LUT6 #(
    .INIT(64'hFFFF35FF35FF0000)) 
    g_INST_0_i_1
       (.I0(s[2]),
        .I1(s[3]),
        .I2(b[0]),
        .I3(a[0]),
        .I4(\f[3]_INST_0_i_6_n_0 ),
        .I5(\f[3]_INST_0_i_5_n_0 ),
        .O(g_INST_0_i_1_n_0));
  LUT4 #(
    .INIT(16'h0080)) 
    p_INST_0
       (.I0(\f[2]_INST_0_i_1_n_0 ),
        .I1(\f[3]_INST_0_i_1_n_0 ),
        .I2(\f[1]_INST_0_i_3_n_0 ),
        .I3(\f[0]_INST_0_i_1_n_0 ),
        .O(p));
  LUT6 #(
    .INIT(64'h0550000004411000)) 
    zero_INST_0
       (.I0(zero_INST_0_i_1_n_0),
        .I1(\f[3]_INST_0_i_4_n_0 ),
        .I2(\f[3]_INST_0_i_3_n_0 ),
        .I3(\f[3]_INST_0_i_2_n_0 ),
        .I4(\f[3]_INST_0_i_1_n_0 ),
        .I5(m),
        .O(zero));
  LUT5 #(
    .INIT(32'h7D7D7DE7)) 
    zero_INST_0_i_1
       (.I0(\f[1]_INST_0_i_3_n_0 ),
        .I1(\f[1]_INST_0_i_2_n_0 ),
        .I2(\f[1]_INST_0_i_1_n_0 ),
        .I3(cin),
        .I4(m),
        .O(zero_INST_0_i_1_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
