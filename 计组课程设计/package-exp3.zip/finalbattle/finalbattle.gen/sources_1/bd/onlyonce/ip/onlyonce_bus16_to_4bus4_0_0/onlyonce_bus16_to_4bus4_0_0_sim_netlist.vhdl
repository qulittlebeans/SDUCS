-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 17:18:23 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus16_to_4bus4_0_0/onlyonce_bus16_to_4bus4_0_0_sim_netlist.vhdl
-- Design      : onlyonce_bus16_to_4bus4_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_bus16_to_4bus4_0_0 is
  port (
    bus_in : in STD_LOGIC_VECTOR ( 15 downto 0 );
    bus_out0 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bus_out1 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bus_out2 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bus_out3 : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_bus16_to_4bus4_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bus16_to_4bus4_0_0 : entity is "onlyonce_bus16_to_4bus4_0_0,bus16_to_4bus4,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bus16_to_4bus4_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bus16_to_4bus4_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_bus16_to_4bus4_0_0 : entity is "bus16_to_4bus4,Vivado 2024.2";
end onlyonce_bus16_to_4bus4_0_0;

architecture STRUCTURE of onlyonce_bus16_to_4bus4_0_0 is
  signal \^bus_in\ : STD_LOGIC_VECTOR ( 15 downto 0 );
begin
  \^bus_in\(15 downto 0) <= bus_in(15 downto 0);
  bus_out0(3 downto 0) <= \^bus_in\(3 downto 0);
  bus_out1(3 downto 0) <= \^bus_in\(7 downto 4);
  bus_out2(3 downto 0) <= \^bus_in\(11 downto 8);
  bus_out3(3 downto 0) <= \^bus_in\(15 downto 12);
end STRUCTURE;
