-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 19:42:41 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus10_to_3x4_0_0/onlyonce_bus10_to_3x4_0_0_sim_netlist.vhdl
-- Design      : onlyonce_bus10_to_3x4_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_bus10_to_3x4_0_0 is
  port (
    in10 : in STD_LOGIC_VECTOR ( 9 downto 0 );
    out_low : out STD_LOGIC_VECTOR ( 3 downto 0 );
    out_mid : out STD_LOGIC_VECTOR ( 3 downto 0 );
    out_high : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_bus10_to_3x4_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bus10_to_3x4_0_0 : entity is "onlyonce_bus10_to_3x4_0_0,bus10_to_3x4,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bus10_to_3x4_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bus10_to_3x4_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_bus10_to_3x4_0_0 : entity is "bus10_to_3x4,Vivado 2024.2";
end onlyonce_bus10_to_3x4_0_0;

architecture STRUCTURE of onlyonce_bus10_to_3x4_0_0 is
  signal \<const0>\ : STD_LOGIC;
  signal \^in10\ : STD_LOGIC_VECTOR ( 9 downto 0 );
begin
  \^in10\(9 downto 0) <= in10(9 downto 0);
  out_high(3) <= \<const0>\;
  out_high(2) <= \<const0>\;
  out_high(1 downto 0) <= \^in10\(9 downto 8);
  out_low(3 downto 0) <= \^in10\(3 downto 0);
  out_mid(3 downto 0) <= \^in10\(7 downto 4);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
end STRUCTURE;
