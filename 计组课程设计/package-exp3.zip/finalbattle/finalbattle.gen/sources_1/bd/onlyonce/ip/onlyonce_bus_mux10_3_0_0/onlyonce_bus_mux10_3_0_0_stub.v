// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Wed Nov 12 19:24:51 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus_mux10_3_0_0/onlyonce_bus_mux10_3_0_0_stub.v
// Design      : onlyonce_bus_mux10_3_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_bus_mux10_3_0_0,bus_mux10_3,{}" *) (* CORE_GENERATION_INFO = "onlyonce_bus_mux10_3_0_0,bus_mux10_3,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bus_mux10_3,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "bus_mux10_3,Vivado 2024.2" *) 
module onlyonce_bus_mux10_3_0_0(in0, in1, in2, en0, en1, en2, bus_out, conflict)
/* synthesis syn_black_box black_box_pad_pin="in0[9:0],in1[9:0],in2[9:0],en0,en1,en2,bus_out[9:0],conflict" */;
  input [9:0]in0;
  input [9:0]in1;
  input [9:0]in2;
  input en0;
  input en1;
  input en2;
  output [9:0]bus_out;
  output conflict;
endmodule
