-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 17:21:45 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_IR_0_0/onlyonce_IR_0_0_sim_netlist.vhdl
-- Design      : onlyonce_IR_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_IR_0_0 is
  port (
    IR : in STD_LOGIC_VECTOR ( 15 downto 0 );
    qjp_addr : out STD_LOGIC_VECTOR ( 9 downto 0 );
    mjp_addr : out STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_IR_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_IR_0_0 : entity is "onlyonce_IR_0_0,IR,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_IR_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_IR_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_IR_0_0 : entity is "IR,Vivado 2024.2";
end onlyonce_IR_0_0;

architecture STRUCTURE of onlyonce_IR_0_0 is
  signal \<const0>\ : STD_LOGIC;
  signal \<const1>\ : STD_LOGIC;
  signal \^ir\ : STD_LOGIC_VECTOR ( 15 downto 0 );
begin
  \^ir\(15 downto 10) <= IR(15 downto 10);
  \^ir\(6 downto 5) <= IR(6 downto 5);
  mjp_addr(9) <= \<const0>\;
  mjp_addr(8) <= \<const0>\;
  mjp_addr(7) <= \<const0>\;
  mjp_addr(6) <= \<const0>\;
  mjp_addr(5) <= \<const0>\;
  mjp_addr(4) <= \<const1>\;
  mjp_addr(3) <= \<const1>\;
  mjp_addr(2 downto 1) <= \^ir\(6 downto 5);
  mjp_addr(0) <= \<const0>\;
  qjp_addr(9 downto 4) <= \^ir\(15 downto 10);
  qjp_addr(3) <= \<const0>\;
  qjp_addr(2) <= \<const0>\;
  qjp_addr(1) <= \<const0>\;
  qjp_addr(0) <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
VCC: unisim.vcomponents.VCC
     port map (
      P => \<const1>\
    );
end STRUCTURE;
