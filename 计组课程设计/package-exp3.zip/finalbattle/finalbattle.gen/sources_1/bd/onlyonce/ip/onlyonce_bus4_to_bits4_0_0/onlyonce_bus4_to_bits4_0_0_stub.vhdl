-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 17:18:19 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus4_to_bits4_0_0/onlyonce_bus4_to_bits4_0_0_stub.vhdl
-- Design      : onlyonce_bus4_to_bits4_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity onlyonce_bus4_to_bits4_0_0 is
  Port ( 
    bus_in : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bit0 : out STD_LOGIC;
    bit1 : out STD_LOGIC;
    bit2 : out STD_LOGIC;
    bit3 : out STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bus4_to_bits4_0_0 : entity is "onlyonce_bus4_to_bits4_0_0,bus4_to_bits4,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of onlyonce_bus4_to_bits4_0_0 : entity is "onlyonce_bus4_to_bits4_0_0,bus4_to_bits4,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bus4_to_bits4,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bus4_to_bits4_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bus4_to_bits4_0_0 : entity is "module_ref";
end onlyonce_bus4_to_bits4_0_0;

architecture stub of onlyonce_bus4_to_bits4_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "bus_in[3:0],bit0,bit1,bit2,bit3";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "bus4_to_bits4,Vivado 2024.2";
begin
end;
