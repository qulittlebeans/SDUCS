-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 19:42:41 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_truncate16_to_8_0_0/onlyonce_truncate16_to_8_0_0_sim_netlist.vhdl
-- Design      : onlyonce_truncate16_to_8_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_truncate16_to_8_0_0 is
  port (
    in16 : in STD_LOGIC_VECTOR ( 15 downto 0 );
    out8 : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_truncate16_to_8_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_truncate16_to_8_0_0 : entity is "onlyonce_truncate16_to_8_0_0,truncate16_to_8,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_truncate16_to_8_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_truncate16_to_8_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_truncate16_to_8_0_0 : entity is "truncate16_to_8,Vivado 2024.2";
end onlyonce_truncate16_to_8_0_0;

architecture STRUCTURE of onlyonce_truncate16_to_8_0_0 is
  signal \^in16\ : STD_LOGIC_VECTOR ( 15 downto 0 );
begin
  \^in16\(7 downto 0) <= in16(7 downto 0);
  out8(7 downto 0) <= \^in16\(7 downto 0);
end STRUCTURE;
