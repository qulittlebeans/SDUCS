// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Wed Nov 12 19:24:52 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus_mux16_0_0/onlyonce_bus_mux16_0_0_sim_netlist.v
// Design      : onlyonce_bus_mux16_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "onlyonce_bus_mux16_0_0,bus_mux16,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "bus_mux16,Vivado 2024.2" *) 
(* NotValidForBitStream *)
module onlyonce_bus_mux16_0_0
   (PCout,
    DRout,
    Zout,
    R2out,
    R1out,
    R0out,
    IRout,
    PCout_en,
    DRout_en,
    Zout_en,
    R2out_en,
    R1out_en,
    R0out_en,
    IRout_en,
    bus_out,
    conflict);
  input [15:0]PCout;
  input [15:0]DRout;
  input [15:0]Zout;
  input [15:0]R2out;
  input [15:0]R1out;
  input [15:0]R0out;
  input [15:0]IRout;
  input PCout_en;
  input DRout_en;
  input Zout_en;
  input R2out_en;
  input R1out_en;
  input R0out_en;
  input IRout_en;
  output [15:0]bus_out;
  output conflict;

  wire [15:0]DRout;
  wire DRout_en;
  wire [15:0]IRout;
  wire IRout_en;
  wire [15:0]PCout;
  wire PCout_en;
  wire [15:0]R0out;
  wire R0out_en;
  wire [15:0]R1out;
  wire R1out_en;
  wire [15:0]R2out;
  wire R2out_en;
  wire [15:0]Zout;
  wire Zout_en;
  wire [15:0]bus_out;
  wire \bus_out[0]_INST_0_i_1_n_0 ;
  wire \bus_out[0]_INST_0_i_2_n_0 ;
  wire \bus_out[0]_INST_0_i_3_n_0 ;
  wire \bus_out[10]_INST_0_i_1_n_0 ;
  wire \bus_out[10]_INST_0_i_2_n_0 ;
  wire \bus_out[10]_INST_0_i_3_n_0 ;
  wire \bus_out[11]_INST_0_i_1_n_0 ;
  wire \bus_out[11]_INST_0_i_2_n_0 ;
  wire \bus_out[11]_INST_0_i_3_n_0 ;
  wire \bus_out[12]_INST_0_i_1_n_0 ;
  wire \bus_out[12]_INST_0_i_2_n_0 ;
  wire \bus_out[12]_INST_0_i_3_n_0 ;
  wire \bus_out[13]_INST_0_i_1_n_0 ;
  wire \bus_out[13]_INST_0_i_2_n_0 ;
  wire \bus_out[13]_INST_0_i_3_n_0 ;
  wire \bus_out[14]_INST_0_i_1_n_0 ;
  wire \bus_out[14]_INST_0_i_2_n_0 ;
  wire \bus_out[14]_INST_0_i_3_n_0 ;
  wire \bus_out[15]_INST_0_i_1_n_0 ;
  wire \bus_out[15]_INST_0_i_2_n_0 ;
  wire \bus_out[15]_INST_0_i_3_n_0 ;
  wire \bus_out[15]_INST_0_i_4_n_0 ;
  wire \bus_out[15]_INST_0_i_5_n_0 ;
  wire \bus_out[1]_INST_0_i_1_n_0 ;
  wire \bus_out[1]_INST_0_i_2_n_0 ;
  wire \bus_out[1]_INST_0_i_3_n_0 ;
  wire \bus_out[2]_INST_0_i_1_n_0 ;
  wire \bus_out[2]_INST_0_i_2_n_0 ;
  wire \bus_out[2]_INST_0_i_3_n_0 ;
  wire \bus_out[3]_INST_0_i_1_n_0 ;
  wire \bus_out[3]_INST_0_i_2_n_0 ;
  wire \bus_out[3]_INST_0_i_3_n_0 ;
  wire \bus_out[4]_INST_0_i_1_n_0 ;
  wire \bus_out[4]_INST_0_i_2_n_0 ;
  wire \bus_out[4]_INST_0_i_3_n_0 ;
  wire \bus_out[5]_INST_0_i_1_n_0 ;
  wire \bus_out[5]_INST_0_i_2_n_0 ;
  wire \bus_out[5]_INST_0_i_3_n_0 ;
  wire \bus_out[6]_INST_0_i_1_n_0 ;
  wire \bus_out[6]_INST_0_i_2_n_0 ;
  wire \bus_out[6]_INST_0_i_3_n_0 ;
  wire \bus_out[7]_INST_0_i_1_n_0 ;
  wire \bus_out[7]_INST_0_i_2_n_0 ;
  wire \bus_out[7]_INST_0_i_3_n_0 ;
  wire \bus_out[8]_INST_0_i_1_n_0 ;
  wire \bus_out[8]_INST_0_i_2_n_0 ;
  wire \bus_out[8]_INST_0_i_3_n_0 ;
  wire \bus_out[9]_INST_0_i_1_n_0 ;
  wire \bus_out[9]_INST_0_i_2_n_0 ;
  wire \bus_out[9]_INST_0_i_3_n_0 ;
  wire conflict;
  wire conflict_INST_0_i_1_n_0;
  wire conflict_INST_0_i_2_n_0;

  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[0]_INST_0 
       (.I0(\bus_out[0]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[0]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[0]_INST_0_i_1 
       (.I0(PCout[0]),
        .I1(PCout_en),
        .I2(\bus_out[0]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[0]_INST_0_i_3_n_0 ),
        .O(\bus_out[0]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[0]_INST_0_i_2 
       (.I0(Zout[0]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[0]),
        .I4(R2out_en),
        .I5(DRout[0]),
        .O(\bus_out[0]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[0]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[0]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[0]),
        .I5(IRout[0]),
        .O(\bus_out[0]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[10]_INST_0 
       (.I0(\bus_out[10]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[10]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[10]_INST_0_i_1 
       (.I0(PCout[10]),
        .I1(PCout_en),
        .I2(\bus_out[10]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[10]_INST_0_i_3_n_0 ),
        .O(\bus_out[10]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[10]_INST_0_i_2 
       (.I0(Zout[10]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[10]),
        .I4(R2out_en),
        .I5(DRout[10]),
        .O(\bus_out[10]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[10]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[10]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[10]),
        .I5(IRout[10]),
        .O(\bus_out[10]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[11]_INST_0 
       (.I0(\bus_out[11]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[11]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[11]_INST_0_i_1 
       (.I0(PCout[11]),
        .I1(PCout_en),
        .I2(\bus_out[11]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[11]_INST_0_i_3_n_0 ),
        .O(\bus_out[11]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[11]_INST_0_i_2 
       (.I0(Zout[11]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[11]),
        .I4(R2out_en),
        .I5(DRout[11]),
        .O(\bus_out[11]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[11]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[11]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[11]),
        .I5(IRout[11]),
        .O(\bus_out[11]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[12]_INST_0 
       (.I0(\bus_out[12]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[12]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[12]_INST_0_i_1 
       (.I0(PCout[12]),
        .I1(PCout_en),
        .I2(\bus_out[12]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[12]_INST_0_i_3_n_0 ),
        .O(\bus_out[12]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[12]_INST_0_i_2 
       (.I0(Zout[12]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[12]),
        .I4(R2out_en),
        .I5(DRout[12]),
        .O(\bus_out[12]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[12]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[12]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[12]),
        .I5(IRout[12]),
        .O(\bus_out[12]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[13]_INST_0 
       (.I0(\bus_out[13]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[13]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[13]_INST_0_i_1 
       (.I0(PCout[13]),
        .I1(PCout_en),
        .I2(\bus_out[13]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[13]_INST_0_i_3_n_0 ),
        .O(\bus_out[13]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[13]_INST_0_i_2 
       (.I0(Zout[13]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[13]),
        .I4(R2out_en),
        .I5(DRout[13]),
        .O(\bus_out[13]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[13]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[13]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[13]),
        .I5(IRout[13]),
        .O(\bus_out[13]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[14]_INST_0 
       (.I0(\bus_out[14]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[14]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[14]_INST_0_i_1 
       (.I0(PCout[14]),
        .I1(PCout_en),
        .I2(\bus_out[14]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[14]_INST_0_i_3_n_0 ),
        .O(\bus_out[14]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[14]_INST_0_i_2 
       (.I0(Zout[14]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[14]),
        .I4(R2out_en),
        .I5(DRout[14]),
        .O(\bus_out[14]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[14]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[14]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[14]),
        .I5(IRout[14]),
        .O(\bus_out[14]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[15]_INST_0 
       (.I0(\bus_out[15]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[15]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[15]_INST_0_i_1 
       (.I0(PCout[15]),
        .I1(PCout_en),
        .I2(\bus_out[15]_INST_0_i_3_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[15]_INST_0_i_5_n_0 ),
        .O(\bus_out[15]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000069960069)) 
    \bus_out[15]_INST_0_i_2 
       (.I0(DRout_en),
        .I1(Zout_en),
        .I2(R2out_en),
        .I3(PCout_en),
        .I4(conflict_INST_0_i_2_n_0),
        .I5(conflict_INST_0_i_1_n_0),
        .O(\bus_out[15]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[15]_INST_0_i_3 
       (.I0(Zout[15]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[15]),
        .I4(R2out_en),
        .I5(DRout[15]),
        .O(\bus_out[15]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \bus_out[15]_INST_0_i_4 
       (.I0(DRout_en),
        .I1(Zout_en),
        .O(\bus_out[15]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[15]_INST_0_i_5 
       (.I0(IRout_en),
        .I1(R1out[15]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[15]),
        .I5(IRout[15]),
        .O(\bus_out[15]_INST_0_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[1]_INST_0 
       (.I0(\bus_out[1]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[1]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[1]_INST_0_i_1 
       (.I0(PCout[1]),
        .I1(PCout_en),
        .I2(\bus_out[1]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[1]_INST_0_i_3_n_0 ),
        .O(\bus_out[1]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[1]_INST_0_i_2 
       (.I0(Zout[1]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[1]),
        .I4(R2out_en),
        .I5(DRout[1]),
        .O(\bus_out[1]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[1]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[1]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[1]),
        .I5(IRout[1]),
        .O(\bus_out[1]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[2]_INST_0 
       (.I0(\bus_out[2]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[2]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[2]_INST_0_i_1 
       (.I0(PCout[2]),
        .I1(PCout_en),
        .I2(\bus_out[2]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[2]_INST_0_i_3_n_0 ),
        .O(\bus_out[2]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[2]_INST_0_i_2 
       (.I0(Zout[2]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[2]),
        .I4(R2out_en),
        .I5(DRout[2]),
        .O(\bus_out[2]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[2]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[2]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[2]),
        .I5(IRout[2]),
        .O(\bus_out[2]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[3]_INST_0 
       (.I0(\bus_out[3]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[3]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[3]_INST_0_i_1 
       (.I0(PCout[3]),
        .I1(PCout_en),
        .I2(\bus_out[3]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[3]_INST_0_i_3_n_0 ),
        .O(\bus_out[3]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[3]_INST_0_i_2 
       (.I0(Zout[3]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[3]),
        .I4(R2out_en),
        .I5(DRout[3]),
        .O(\bus_out[3]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[3]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[3]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[3]),
        .I5(IRout[3]),
        .O(\bus_out[3]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[4]_INST_0 
       (.I0(\bus_out[4]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[4]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[4]_INST_0_i_1 
       (.I0(PCout[4]),
        .I1(PCout_en),
        .I2(\bus_out[4]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[4]_INST_0_i_3_n_0 ),
        .O(\bus_out[4]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[4]_INST_0_i_2 
       (.I0(Zout[4]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[4]),
        .I4(R2out_en),
        .I5(DRout[4]),
        .O(\bus_out[4]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[4]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[4]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[4]),
        .I5(IRout[4]),
        .O(\bus_out[4]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[5]_INST_0 
       (.I0(\bus_out[5]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[5]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[5]_INST_0_i_1 
       (.I0(PCout[5]),
        .I1(PCout_en),
        .I2(\bus_out[5]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[5]_INST_0_i_3_n_0 ),
        .O(\bus_out[5]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[5]_INST_0_i_2 
       (.I0(Zout[5]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[5]),
        .I4(R2out_en),
        .I5(DRout[5]),
        .O(\bus_out[5]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[5]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[5]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[5]),
        .I5(IRout[5]),
        .O(\bus_out[5]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[6]_INST_0 
       (.I0(\bus_out[6]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[6]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[6]_INST_0_i_1 
       (.I0(PCout[6]),
        .I1(PCout_en),
        .I2(\bus_out[6]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[6]_INST_0_i_3_n_0 ),
        .O(\bus_out[6]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[6]_INST_0_i_2 
       (.I0(Zout[6]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[6]),
        .I4(R2out_en),
        .I5(DRout[6]),
        .O(\bus_out[6]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[6]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[6]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[6]),
        .I5(IRout[6]),
        .O(\bus_out[6]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[7]_INST_0 
       (.I0(\bus_out[7]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[7]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[7]_INST_0_i_1 
       (.I0(PCout[7]),
        .I1(PCout_en),
        .I2(\bus_out[7]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[7]_INST_0_i_3_n_0 ),
        .O(\bus_out[7]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[7]_INST_0_i_2 
       (.I0(Zout[7]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[7]),
        .I4(R2out_en),
        .I5(DRout[7]),
        .O(\bus_out[7]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[7]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[7]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[7]),
        .I5(IRout[7]),
        .O(\bus_out[7]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[8]_INST_0 
       (.I0(\bus_out[8]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[8]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[8]_INST_0_i_1 
       (.I0(PCout[8]),
        .I1(PCout_en),
        .I2(\bus_out[8]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[8]_INST_0_i_3_n_0 ),
        .O(\bus_out[8]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[8]_INST_0_i_2 
       (.I0(Zout[8]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[8]),
        .I4(R2out_en),
        .I5(DRout[8]),
        .O(\bus_out[8]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[8]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[8]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[8]),
        .I5(IRout[8]),
        .O(\bus_out[8]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bus_out[9]_INST_0 
       (.I0(\bus_out[9]_INST_0_i_1_n_0 ),
        .I1(\bus_out[15]_INST_0_i_2_n_0 ),
        .O(bus_out[9]));
  LUT6 #(
    .INIT(64'h8B8B8B8B8B8B888B)) 
    \bus_out[9]_INST_0_i_1 
       (.I0(PCout[9]),
        .I1(PCout_en),
        .I2(\bus_out[9]_INST_0_i_2_n_0 ),
        .I3(\bus_out[15]_INST_0_i_4_n_0 ),
        .I4(R2out_en),
        .I5(\bus_out[9]_INST_0_i_3_n_0 ),
        .O(\bus_out[9]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h04070404F4F7F4F4)) 
    \bus_out[9]_INST_0_i_2 
       (.I0(Zout[9]),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R2out[9]),
        .I4(R2out_en),
        .I5(DRout[9]),
        .O(\bus_out[9]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCFCAC0CACFC0C0C0)) 
    \bus_out[9]_INST_0_i_3 
       (.I0(IRout_en),
        .I1(R1out[9]),
        .I2(R1out_en),
        .I3(R0out_en),
        .I4(R0out[9]),
        .I5(IRout[9]),
        .O(\bus_out[9]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFBBABAFBBAFBFBBA)) 
    conflict_INST_0
       (.I0(conflict_INST_0_i_1_n_0),
        .I1(conflict_INST_0_i_2_n_0),
        .I2(PCout_en),
        .I3(R2out_en),
        .I4(Zout_en),
        .I5(DRout_en),
        .O(conflict));
  LUT6 #(
    .INIT(64'hFFFFFFE8FFE8E8E8)) 
    conflict_INST_0_i_1
       (.I0(R2out_en),
        .I1(Zout_en),
        .I2(DRout_en),
        .I3(R0out_en),
        .I4(R1out_en),
        .I5(IRout_en),
        .O(conflict_INST_0_i_1_n_0));
  LUT3 #(
    .INIT(8'h69)) 
    conflict_INST_0_i_2
       (.I0(IRout_en),
        .I1(R0out_en),
        .I2(R1out_en),
        .O(conflict_INST_0_i_2_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
