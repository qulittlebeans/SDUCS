// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 11 17:16:30 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus8_to_bits8_2_0/onlyonce_bus8_to_bits8_2_0_stub.v
// Design      : onlyonce_bus8_to_bits8_2_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_bus8_to_bits8_2_0,bus8_to_bits8,{}" *) (* CORE_GENERATION_INFO = "onlyonce_bus8_to_bits8_2_0,bus8_to_bits8,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bus8_to_bits8,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "bus8_to_bits8,Vivado 2024.2" *) 
module onlyonce_bus8_to_bits8_2_0(bus_in, bit0, bit1, bit2, bit3, bit4, bit5, bit6, bit7)
/* synthesis syn_black_box black_box_pad_pin="bus_in[7:0],bit0,bit1,bit2,bit3,bit4,bit5,bit6,bit7" */;
  input [7:0]bus_in;
  output bit0;
  output bit1;
  output bit2;
  output bit3;
  output bit4;
  output bit5;
  output bit6;
  output bit7;
endmodule
