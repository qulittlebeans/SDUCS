// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 11 19:42:41 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus10_to_3x4_0_0/onlyonce_bus10_to_3x4_0_0_stub.v
// Design      : onlyonce_bus10_to_3x4_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_bus10_to_3x4_0_0,bus10_to_3x4,{}" *) (* CORE_GENERATION_INFO = "onlyonce_bus10_to_3x4_0_0,bus10_to_3x4,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=bus10_to_3x4,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "bus10_to_3x4,Vivado 2024.2" *) 
module onlyonce_bus10_to_3x4_0_0(in10, out_low, out_mid, out_high)
/* synthesis syn_black_box black_box_pad_pin="in10[9:0],out_low[3:0],out_mid[3:0],out_high[3:0]" */;
  input [9:0]in10;
  output [3:0]out_low;
  output [3:0]out_mid;
  output [3:0]out_high;
endmodule
