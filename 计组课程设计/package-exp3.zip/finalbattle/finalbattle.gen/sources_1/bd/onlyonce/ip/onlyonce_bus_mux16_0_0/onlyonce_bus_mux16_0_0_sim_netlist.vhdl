-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Wed Nov 12 19:24:52 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_bus_mux16_0_0/onlyonce_bus_mux16_0_0_sim_netlist.vhdl
-- Design      : onlyonce_bus_mux16_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_bus_mux16_0_0 is
  port (
    PCout : in STD_LOGIC_VECTOR ( 15 downto 0 );
    DRout : in STD_LOGIC_VECTOR ( 15 downto 0 );
    Zout : in STD_LOGIC_VECTOR ( 15 downto 0 );
    R2out : in STD_LOGIC_VECTOR ( 15 downto 0 );
    R1out : in STD_LOGIC_VECTOR ( 15 downto 0 );
    R0out : in STD_LOGIC_VECTOR ( 15 downto 0 );
    IRout : in STD_LOGIC_VECTOR ( 15 downto 0 );
    PCout_en : in STD_LOGIC;
    DRout_en : in STD_LOGIC;
    Zout_en : in STD_LOGIC;
    R2out_en : in STD_LOGIC;
    R1out_en : in STD_LOGIC;
    R0out_en : in STD_LOGIC;
    IRout_en : in STD_LOGIC;
    bus_out : out STD_LOGIC_VECTOR ( 15 downto 0 );
    conflict : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_bus_mux16_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_bus_mux16_0_0 : entity is "onlyonce_bus_mux16_0_0,bus_mux16,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_bus_mux16_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_bus_mux16_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_bus_mux16_0_0 : entity is "bus_mux16,Vivado 2024.2";
end onlyonce_bus_mux16_0_0;

architecture STRUCTURE of onlyonce_bus_mux16_0_0 is
  signal \bus_out[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[10]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[10]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[10]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[11]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[11]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[11]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[12]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[12]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[12]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[13]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[13]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[13]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[14]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[14]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[14]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[15]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[15]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[15]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[15]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bus_out[15]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bus_out[1]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[1]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[1]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[2]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[2]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[2]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[3]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[4]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[4]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[5]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[5]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[6]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[6]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[6]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[7]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[7]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[8]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[8]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bus_out[9]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bus_out[9]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bus_out[9]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal conflict_INST_0_i_1_n_0 : STD_LOGIC;
  signal conflict_INST_0_i_2_n_0 : STD_LOGIC;
begin
\bus_out[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[0]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(0)
    );
\bus_out[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(0),
      I1 => PCout_en,
      I2 => \bus_out[0]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[0]_INST_0_i_3_n_0\,
      O => \bus_out[0]_INST_0_i_1_n_0\
    );
\bus_out[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(0),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(0),
      I4 => R2out_en,
      I5 => DRout(0),
      O => \bus_out[0]_INST_0_i_2_n_0\
    );
\bus_out[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(0),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(0),
      I5 => IRout(0),
      O => \bus_out[0]_INST_0_i_3_n_0\
    );
\bus_out[10]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[10]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(10)
    );
\bus_out[10]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(10),
      I1 => PCout_en,
      I2 => \bus_out[10]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[10]_INST_0_i_3_n_0\,
      O => \bus_out[10]_INST_0_i_1_n_0\
    );
\bus_out[10]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(10),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(10),
      I4 => R2out_en,
      I5 => DRout(10),
      O => \bus_out[10]_INST_0_i_2_n_0\
    );
\bus_out[10]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(10),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(10),
      I5 => IRout(10),
      O => \bus_out[10]_INST_0_i_3_n_0\
    );
\bus_out[11]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[11]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(11)
    );
\bus_out[11]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(11),
      I1 => PCout_en,
      I2 => \bus_out[11]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[11]_INST_0_i_3_n_0\,
      O => \bus_out[11]_INST_0_i_1_n_0\
    );
\bus_out[11]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(11),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(11),
      I4 => R2out_en,
      I5 => DRout(11),
      O => \bus_out[11]_INST_0_i_2_n_0\
    );
\bus_out[11]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(11),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(11),
      I5 => IRout(11),
      O => \bus_out[11]_INST_0_i_3_n_0\
    );
\bus_out[12]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[12]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(12)
    );
\bus_out[12]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(12),
      I1 => PCout_en,
      I2 => \bus_out[12]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[12]_INST_0_i_3_n_0\,
      O => \bus_out[12]_INST_0_i_1_n_0\
    );
\bus_out[12]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(12),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(12),
      I4 => R2out_en,
      I5 => DRout(12),
      O => \bus_out[12]_INST_0_i_2_n_0\
    );
\bus_out[12]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(12),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(12),
      I5 => IRout(12),
      O => \bus_out[12]_INST_0_i_3_n_0\
    );
\bus_out[13]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[13]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(13)
    );
\bus_out[13]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(13),
      I1 => PCout_en,
      I2 => \bus_out[13]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[13]_INST_0_i_3_n_0\,
      O => \bus_out[13]_INST_0_i_1_n_0\
    );
\bus_out[13]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(13),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(13),
      I4 => R2out_en,
      I5 => DRout(13),
      O => \bus_out[13]_INST_0_i_2_n_0\
    );
\bus_out[13]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(13),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(13),
      I5 => IRout(13),
      O => \bus_out[13]_INST_0_i_3_n_0\
    );
\bus_out[14]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[14]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(14)
    );
\bus_out[14]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(14),
      I1 => PCout_en,
      I2 => \bus_out[14]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[14]_INST_0_i_3_n_0\,
      O => \bus_out[14]_INST_0_i_1_n_0\
    );
\bus_out[14]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(14),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(14),
      I4 => R2out_en,
      I5 => DRout(14),
      O => \bus_out[14]_INST_0_i_2_n_0\
    );
\bus_out[14]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(14),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(14),
      I5 => IRout(14),
      O => \bus_out[14]_INST_0_i_3_n_0\
    );
\bus_out[15]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[15]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(15)
    );
\bus_out[15]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(15),
      I1 => PCout_en,
      I2 => \bus_out[15]_INST_0_i_3_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[15]_INST_0_i_5_n_0\,
      O => \bus_out[15]_INST_0_i_1_n_0\
    );
\bus_out[15]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000069960069"
    )
        port map (
      I0 => DRout_en,
      I1 => Zout_en,
      I2 => R2out_en,
      I3 => PCout_en,
      I4 => conflict_INST_0_i_2_n_0,
      I5 => conflict_INST_0_i_1_n_0,
      O => \bus_out[15]_INST_0_i_2_n_0\
    );
\bus_out[15]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(15),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(15),
      I4 => R2out_en,
      I5 => DRout(15),
      O => \bus_out[15]_INST_0_i_3_n_0\
    );
\bus_out[15]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => DRout_en,
      I1 => Zout_en,
      O => \bus_out[15]_INST_0_i_4_n_0\
    );
\bus_out[15]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(15),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(15),
      I5 => IRout(15),
      O => \bus_out[15]_INST_0_i_5_n_0\
    );
\bus_out[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[1]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(1)
    );
\bus_out[1]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(1),
      I1 => PCout_en,
      I2 => \bus_out[1]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[1]_INST_0_i_3_n_0\,
      O => \bus_out[1]_INST_0_i_1_n_0\
    );
\bus_out[1]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(1),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(1),
      I4 => R2out_en,
      I5 => DRout(1),
      O => \bus_out[1]_INST_0_i_2_n_0\
    );
\bus_out[1]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(1),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(1),
      I5 => IRout(1),
      O => \bus_out[1]_INST_0_i_3_n_0\
    );
\bus_out[2]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[2]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(2)
    );
\bus_out[2]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(2),
      I1 => PCout_en,
      I2 => \bus_out[2]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[2]_INST_0_i_3_n_0\,
      O => \bus_out[2]_INST_0_i_1_n_0\
    );
\bus_out[2]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(2),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(2),
      I4 => R2out_en,
      I5 => DRout(2),
      O => \bus_out[2]_INST_0_i_2_n_0\
    );
\bus_out[2]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(2),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(2),
      I5 => IRout(2),
      O => \bus_out[2]_INST_0_i_3_n_0\
    );
\bus_out[3]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[3]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(3)
    );
\bus_out[3]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(3),
      I1 => PCout_en,
      I2 => \bus_out[3]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[3]_INST_0_i_3_n_0\,
      O => \bus_out[3]_INST_0_i_1_n_0\
    );
\bus_out[3]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(3),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(3),
      I4 => R2out_en,
      I5 => DRout(3),
      O => \bus_out[3]_INST_0_i_2_n_0\
    );
\bus_out[3]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(3),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(3),
      I5 => IRout(3),
      O => \bus_out[3]_INST_0_i_3_n_0\
    );
\bus_out[4]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[4]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(4)
    );
\bus_out[4]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(4),
      I1 => PCout_en,
      I2 => \bus_out[4]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[4]_INST_0_i_3_n_0\,
      O => \bus_out[4]_INST_0_i_1_n_0\
    );
\bus_out[4]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(4),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(4),
      I4 => R2out_en,
      I5 => DRout(4),
      O => \bus_out[4]_INST_0_i_2_n_0\
    );
\bus_out[4]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(4),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(4),
      I5 => IRout(4),
      O => \bus_out[4]_INST_0_i_3_n_0\
    );
\bus_out[5]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[5]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(5)
    );
\bus_out[5]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(5),
      I1 => PCout_en,
      I2 => \bus_out[5]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[5]_INST_0_i_3_n_0\,
      O => \bus_out[5]_INST_0_i_1_n_0\
    );
\bus_out[5]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(5),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(5),
      I4 => R2out_en,
      I5 => DRout(5),
      O => \bus_out[5]_INST_0_i_2_n_0\
    );
\bus_out[5]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(5),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(5),
      I5 => IRout(5),
      O => \bus_out[5]_INST_0_i_3_n_0\
    );
\bus_out[6]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[6]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(6)
    );
\bus_out[6]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(6),
      I1 => PCout_en,
      I2 => \bus_out[6]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[6]_INST_0_i_3_n_0\,
      O => \bus_out[6]_INST_0_i_1_n_0\
    );
\bus_out[6]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(6),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(6),
      I4 => R2out_en,
      I5 => DRout(6),
      O => \bus_out[6]_INST_0_i_2_n_0\
    );
\bus_out[6]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(6),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(6),
      I5 => IRout(6),
      O => \bus_out[6]_INST_0_i_3_n_0\
    );
\bus_out[7]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[7]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(7)
    );
\bus_out[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(7),
      I1 => PCout_en,
      I2 => \bus_out[7]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[7]_INST_0_i_3_n_0\,
      O => \bus_out[7]_INST_0_i_1_n_0\
    );
\bus_out[7]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(7),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(7),
      I4 => R2out_en,
      I5 => DRout(7),
      O => \bus_out[7]_INST_0_i_2_n_0\
    );
\bus_out[7]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(7),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(7),
      I5 => IRout(7),
      O => \bus_out[7]_INST_0_i_3_n_0\
    );
\bus_out[8]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[8]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(8)
    );
\bus_out[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(8),
      I1 => PCout_en,
      I2 => \bus_out[8]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[8]_INST_0_i_3_n_0\,
      O => \bus_out[8]_INST_0_i_1_n_0\
    );
\bus_out[8]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(8),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(8),
      I4 => R2out_en,
      I5 => DRout(8),
      O => \bus_out[8]_INST_0_i_2_n_0\
    );
\bus_out[8]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(8),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(8),
      I5 => IRout(8),
      O => \bus_out[8]_INST_0_i_3_n_0\
    );
\bus_out[9]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bus_out[9]_INST_0_i_1_n_0\,
      I1 => \bus_out[15]_INST_0_i_2_n_0\,
      O => bus_out(9)
    );
\bus_out[9]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8B8B8B8B8B8B888B"
    )
        port map (
      I0 => PCout(9),
      I1 => PCout_en,
      I2 => \bus_out[9]_INST_0_i_2_n_0\,
      I3 => \bus_out[15]_INST_0_i_4_n_0\,
      I4 => R2out_en,
      I5 => \bus_out[9]_INST_0_i_3_n_0\,
      O => \bus_out[9]_INST_0_i_1_n_0\
    );
\bus_out[9]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"04070404F4F7F4F4"
    )
        port map (
      I0 => Zout(9),
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R2out(9),
      I4 => R2out_en,
      I5 => DRout(9),
      O => \bus_out[9]_INST_0_i_2_n_0\
    );
\bus_out[9]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CFCAC0CACFC0C0C0"
    )
        port map (
      I0 => IRout_en,
      I1 => R1out(9),
      I2 => R1out_en,
      I3 => R0out_en,
      I4 => R0out(9),
      I5 => IRout(9),
      O => \bus_out[9]_INST_0_i_3_n_0\
    );
conflict_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBBABAFBBAFBFBBA"
    )
        port map (
      I0 => conflict_INST_0_i_1_n_0,
      I1 => conflict_INST_0_i_2_n_0,
      I2 => PCout_en,
      I3 => R2out_en,
      I4 => Zout_en,
      I5 => DRout_en,
      O => conflict
    );
conflict_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFE8FFE8E8E8"
    )
        port map (
      I0 => R2out_en,
      I1 => Zout_en,
      I2 => DRout_en,
      I3 => R0out_en,
      I4 => R1out_en,
      I5 => IRout_en,
      O => conflict_INST_0_i_1_n_0
    );
conflict_INST_0_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => IRout_en,
      I1 => R0out_en,
      I2 => R1out_en,
      O => conflict_INST_0_i_2_n_0
    );
end STRUCTURE;
