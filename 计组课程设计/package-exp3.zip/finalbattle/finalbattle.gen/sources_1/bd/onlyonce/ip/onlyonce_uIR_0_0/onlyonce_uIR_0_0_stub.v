// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Tue Nov 11 17:16:30 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_uIR_0_0/onlyonce_uIR_0_0_stub.v
// Design      : onlyonce_uIR_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_uIR_0_0,uIR,{}" *) (* CORE_GENERATION_INFO = "onlyonce_uIR_0_0,uIR,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=uIR,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "uIR,Vivado 2024.2" *) 
module onlyonce_uIR_0_0(microIR, M, S, C0, DREout_bit, out_sel, pc_ctrl, Zin, 
  DREin, in_sel, ram_op, G, tr_type, jp_addr)
/* synthesis syn_black_box black_box_pad_pin="microIR[22:0],M,S[3:0],C0,DREout_bit,out_sel[2:0],pc_ctrl[1:0],Zin,DREin,in_sel[2:0],ram_op[1:0],G,tr_type[2:0],jp_addr[9:0]" */;
  input [22:0]microIR;
  output M;
  output [3:0]S;
  output C0;
  output DREout_bit;
  output [2:0]out_sel;
  output [1:0]pc_ctrl;
  output Zin;
  output DREin;
  output [2:0]in_sel;
  output [1:0]ram_op;
  output G;
  output [2:0]tr_type;
  output [9:0]jp_addr;
endmodule
