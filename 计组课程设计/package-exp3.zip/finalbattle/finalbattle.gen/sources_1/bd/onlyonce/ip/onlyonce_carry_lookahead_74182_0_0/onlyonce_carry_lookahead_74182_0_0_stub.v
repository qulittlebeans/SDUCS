// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Wed Nov 12 20:42:05 2025
// Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_carry_lookahead_74182_0_0/onlyonce_carry_lookahead_74182_0_0_stub.v
// Design      : onlyonce_carry_lookahead_74182_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "onlyonce_carry_lookahead_74182_0_0,carry_lookahead_74182,{}" *) (* CORE_GENERATION_INFO = "onlyonce_carry_lookahead_74182_0_0,carry_lookahead_74182,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=carry_lookahead_74182,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "carry_lookahead_74182,Vivado 2024.2" *) 
module onlyonce_carry_lookahead_74182_0_0(p, g, cin, cout, p_group, g_group)
/* synthesis syn_black_box black_box_pad_pin="p[3:0],g[3:0],cin,cout[3:0],p_group,g_group" */;
  input [3:0]p;
  input [3:0]g;
  input cin;
  output [3:0]cout;
  output p_group;
  output g_group;
endmodule
