-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Tue Nov 11 19:42:41 2025
-- Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/IT/Source/vivado/finalbattle/finalbattle.gen/sources_1/bd/onlyonce/ip/onlyonce_extend8_to_16_0_0/onlyonce_extend8_to_16_0_0_sim_netlist.vhdl
-- Design      : onlyonce_extend8_to_16_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity onlyonce_extend8_to_16_0_0 is
  port (
    in8 : in STD_LOGIC_VECTOR ( 7 downto 0 );
    out16 : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of onlyonce_extend8_to_16_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of onlyonce_extend8_to_16_0_0 : entity is "onlyonce_extend8_to_16_0_0,extend8_to_16,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of onlyonce_extend8_to_16_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of onlyonce_extend8_to_16_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of onlyonce_extend8_to_16_0_0 : entity is "extend8_to_16,Vivado 2024.2";
end onlyonce_extend8_to_16_0_0;

architecture STRUCTURE of onlyonce_extend8_to_16_0_0 is
  signal \<const0>\ : STD_LOGIC;
  signal \^in8\ : STD_LOGIC_VECTOR ( 7 downto 0 );
begin
  \^in8\(7 downto 0) <= in8(7 downto 0);
  out16(15) <= \<const0>\;
  out16(14) <= \<const0>\;
  out16(13) <= \<const0>\;
  out16(12) <= \<const0>\;
  out16(11) <= \<const0>\;
  out16(10) <= \<const0>\;
  out16(9) <= \<const0>\;
  out16(8) <= \<const0>\;
  out16(7 downto 0) <= \^in8\(7 downto 0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
end STRUCTURE;
