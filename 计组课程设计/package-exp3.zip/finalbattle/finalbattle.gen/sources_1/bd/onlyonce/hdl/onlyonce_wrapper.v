//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
//Date        : Tue Nov 18 19:49:27 2025
//Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
//Command     : generate_target onlyonce_wrapper.bd
//Design      : onlyonce_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module onlyonce_wrapper
   (CLKK,
    IR,
    MAR,
    MDRR,
    MDRW,
    R0,
    R1,
    R2,
    RSTT,
    Z);
  input CLKK;
  output [15:0]IR;
  output [7:0]MAR;
  output [15:0]MDRR;
  output [15:0]MDRW;
  output [15:0]R0;
  output [15:0]R1;
  output [15:0]R2;
  input RSTT;
  output [15:0]Z;

  wire CLKK;
  wire [15:0]IR;
  wire [7:0]MAR;
  wire [15:0]MDRR;
  wire [15:0]MDRW;
  wire [15:0]R0;
  wire [15:0]R1;
  wire [15:0]R2;
  wire RSTT;
  wire [15:0]Z;

  onlyonce onlyonce_i
       (.CLKK(CLKK),
        .IR(IR),
        .MAR(MAR),
        .MDRR(MDRR),
        .MDRW(MDRW),
        .R0(R0),
        .R1(R1),
        .R2(R2),
        .RSTT(RSTT),
        .Z(Z));
endmodule
