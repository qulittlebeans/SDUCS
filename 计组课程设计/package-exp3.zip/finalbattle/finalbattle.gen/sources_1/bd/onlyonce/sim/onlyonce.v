//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
//Date        : Tue Nov 18 19:49:27 2025
//Host        : LAPTOP-UPRA01UH running 64-bit major release  (build 9200)
//Command     : generate_target onlyonce.bd
//Design      : onlyonce
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module PC_imp_C1137V
   (CR,
    CT,
    LD,
    bus_out,
    clk,
    d);
  input CR;
  input CT;
  input LD;
  output [7:0]bus_out;
  input clk;
  input [3:0]d;

  wire CR;
  wire CT;
  wire LD;
  wire bus4_to_bits4_0_bit0;
  wire bus4_to_bits4_0_bit1;
  wire bus4_to_bits4_0_bit2;
  wire bus4_to_bits4_0_bit3;
  wire bus4_to_bits4_1_bit0;
  wire bus4_to_bits4_1_bit1;
  wire bus4_to_bits4_1_bit2;
  wire bus4_to_bits4_1_bit3;
  wire [7:0]bus_out;
  wire clk;
  wire [3:0]d;
  wire ic_74161_0_CO;
  wire [3:0]ic_74161_0_q;
  wire [3:0]ic_74161_1_q;

  onlyonce_bits8_to_bus8_0_1 bits8_to_bus8_0
       (.bit0(bus4_to_bits4_1_bit0),
        .bit1(bus4_to_bits4_1_bit1),
        .bit2(bus4_to_bits4_1_bit2),
        .bit3(bus4_to_bits4_1_bit3),
        .bit4(bus4_to_bits4_0_bit0),
        .bit5(bus4_to_bits4_0_bit1),
        .bit6(bus4_to_bits4_0_bit2),
        .bit7(bus4_to_bits4_0_bit3),
        .bus_out(bus_out));
  onlyonce_bus4_to_bits4_0_1 bus4_to_bits4_0
       (.bit0(bus4_to_bits4_0_bit0),
        .bit1(bus4_to_bits4_0_bit1),
        .bit2(bus4_to_bits4_0_bit2),
        .bit3(bus4_to_bits4_0_bit3),
        .bus_in(ic_74161_1_q));
  onlyonce_bus4_to_bits4_1_1 bus4_to_bits4_1
       (.bit0(bus4_to_bits4_1_bit0),
        .bit1(bus4_to_bits4_1_bit1),
        .bit2(bus4_to_bits4_1_bit2),
        .bit3(bus4_to_bits4_1_bit3),
        .bus_in(ic_74161_0_q));
  onlyonce_ic_74161_0_1 ic_74161_0
       (.CO(ic_74161_0_CO),
        .CR(CR),
        .CT_p(CT),
        .CT_t(CT),
        .LD(LD),
        .clk(clk),
        .d(d),
        .q(ic_74161_0_q));
  onlyonce_ic_74161_1_1 ic_74161_1
       (.CR(CR),
        .CT_p(ic_74161_0_CO),
        .CT_t(ic_74161_0_CO),
        .LD(LD),
        .clk(clk),
        .d(d),
        .q(ic_74161_1_q));
endmodule

module adder_imp_1CXOY90
   (bus_in,
    bus_in1,
    bus_out,
    cin,
    m,
    s);
  input [15:0]bus_in;
  input [15:0]bus_in1;
  output [15:0]bus_out;
  input cin;
  input m;
  input [3:0]s;

  wire [3:0]alu_74181_0_f;
  wire alu_74181_0_g;
  wire alu_74181_0_p;
  wire [3:0]alu_74181_1_f;
  wire alu_74181_1_g;
  wire alu_74181_1_p;
  wire [3:0]alu_74181_2_f;
  wire alu_74181_2_g;
  wire alu_74181_2_p;
  wire [3:0]alu_74181_3_f;
  wire alu_74181_3_g;
  wire alu_74181_3_p;
  wire [3:0]bits4_to_bus4_0_bus_out;
  wire [3:0]bits4_to_bus4_1_bus_out;
  wire [3:0]bus16_to_4bus4_0_bus_out0;
  wire [3:0]bus16_to_4bus4_0_bus_out1;
  wire [3:0]bus16_to_4bus4_0_bus_out2;
  wire [3:0]bus16_to_4bus4_0_bus_out3;
  wire [3:0]bus16_to_4bus4_1_bus_out0;
  wire [3:0]bus16_to_4bus4_1_bus_out1;
  wire [3:0]bus16_to_4bus4_1_bus_out2;
  wire [3:0]bus16_to_4bus4_1_bus_out3;
  wire bus4_to_bits4_0_bit0;
  wire bus4_to_bits4_0_bit1;
  wire bus4_to_bits4_0_bit2;
  wire [15:0]bus_in;
  wire [15:0]bus_in1;
  wire [15:0]bus_out;
  wire [3:0]carry_lookahead_74182_0_cout;
  wire cin;
  wire m;
  wire not_gate_0_y;
  wire [3:0]s;

  onlyonce_alu_74181_0_0 alu_74181_0
       (.a(bus16_to_4bus4_0_bus_out0),
        .b(bus16_to_4bus4_1_bus_out0),
        .cin(not_gate_0_y),
        .f(alu_74181_0_f),
        .g(alu_74181_0_g),
        .m(m),
        .p(alu_74181_0_p),
        .s(s));
  onlyonce_alu_74181_1_0 alu_74181_1
       (.a(bus16_to_4bus4_0_bus_out1),
        .b(bus16_to_4bus4_1_bus_out1),
        .cin(bus4_to_bits4_0_bit0),
        .f(alu_74181_1_f),
        .g(alu_74181_1_g),
        .m(m),
        .p(alu_74181_1_p),
        .s(s));
  onlyonce_alu_74181_2_0 alu_74181_2
       (.a(bus16_to_4bus4_0_bus_out2),
        .b(bus16_to_4bus4_1_bus_out2),
        .cin(bus4_to_bits4_0_bit1),
        .f(alu_74181_2_f),
        .g(alu_74181_2_g),
        .m(m),
        .p(alu_74181_2_p),
        .s(s));
  onlyonce_alu_74181_3_0 alu_74181_3
       (.a(bus16_to_4bus4_0_bus_out3),
        .b(bus16_to_4bus4_1_bus_out3),
        .cin(bus4_to_bits4_0_bit2),
        .f(alu_74181_3_f),
        .g(alu_74181_3_g),
        .m(m),
        .p(alu_74181_3_p),
        .s(s));
  onlyonce_bits4_to_bus4_0_0 bits4_to_bus4_0
       (.bit0(alu_74181_0_p),
        .bit1(alu_74181_1_p),
        .bit2(alu_74181_2_p),
        .bit3(alu_74181_3_p),
        .bus_out(bits4_to_bus4_0_bus_out));
  onlyonce_bits4_to_bus4_1_0 bits4_to_bus4_1
       (.bit0(alu_74181_0_g),
        .bit1(alu_74181_1_g),
        .bit2(alu_74181_2_g),
        .bit3(alu_74181_3_g),
        .bus_out(bits4_to_bus4_1_bus_out));
  onlyonce_bus16_to_4bus4_0_0 bus16_to_4bus4_0
       (.bus_in(bus_in),
        .bus_out0(bus16_to_4bus4_0_bus_out0),
        .bus_out1(bus16_to_4bus4_0_bus_out1),
        .bus_out2(bus16_to_4bus4_0_bus_out2),
        .bus_out3(bus16_to_4bus4_0_bus_out3));
  onlyonce_bus16_to_4bus4_1_0 bus16_to_4bus4_1
       (.bus_in(bus_in1),
        .bus_out0(bus16_to_4bus4_1_bus_out0),
        .bus_out1(bus16_to_4bus4_1_bus_out1),
        .bus_out2(bus16_to_4bus4_1_bus_out2),
        .bus_out3(bus16_to_4bus4_1_bus_out3));
  onlyonce_bus4_to_bits4_0_0 bus4_to_bits4_0
       (.bit0(bus4_to_bits4_0_bit0),
        .bit1(bus4_to_bits4_0_bit1),
        .bit2(bus4_to_bits4_0_bit2),
        .bus_in(carry_lookahead_74182_0_cout));
  onlyonce_carry_lookahead_74182_0_0 carry_lookahead_74182_0
       (.cin(not_gate_0_y),
        .cout(carry_lookahead_74182_0_cout),
        .g(bits4_to_bus4_1_bus_out),
        .p(bits4_to_bus4_0_bus_out));
  onlyonce_d4bus4_to_bus16_0_0 d4bus4_to_bus16_0
       (.bus_in0(alu_74181_0_f),
        .bus_in1(alu_74181_1_f),
        .bus_in2(alu_74181_2_f),
        .bus_in3(alu_74181_3_f),
        .bus_out(bus_out));
  onlyonce_not_gate_0_1 not_gate_0
       (.a(cin),
        .y(not_gate_0_y));
endmodule

(* CORE_GENERATION_INFO = "onlyonce,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=onlyonce,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=69,numReposBlks=66,numNonXlnxBlks=0,numHierBlks=3,maxHierDepth=1,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=64,numPkgbdBlks=0,bdsource=USER,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "onlyonce.hwdef" *) 
module onlyonce
   (CLKK,
    IR,
    MAR,
    MDRR,
    MDRW,
    R0,
    R1,
    R2,
    RSTT,
    Z);
  input CLKK;
  output [15:0]IR;
  output [7:0]MAR;
  output [15:0]MDRR;
  output [15:0]MDRW;
  output [15:0]R0;
  output [15:0]R1;
  output [15:0]R2;
  input RSTT;
  output [15:0]Z;

  wire CLKK;
  wire [15:0]IR;
  wire [9:0]IR_0_mjp_addr;
  wire [9:0]IR_0_qjp_addr;
  wire [7:0]MAR;
  wire [15:0]MAR_data_out;
  wire [15:0]MDRR;
  wire [15:0]MDRW;
  wire [7:0]PC_bus_out;
  wire [15:0]R0;
  wire [15:0]R1;
  wire [15:0]R2;
  wire RSTT;
  wire [15:0]X_data_out;
  wire [15:0]Z;
  wire [15:0]Z_data_out;
  wire [15:0]adder_bus_out;
  wire and_gate_10_y;
  wire and_gate_1_y;
  wire and_gate_2_y;
  wire and_gate_3_y;
  wire and_gate_4_y;
  wire and_gate_5_y;
  wire and_gate_6_y;
  wire and_gate_7_y;
  wire and_gate_8_y;
  wire and_gate_9_y;
  wire [9:0]bits10_to_bus10_0_bus_out;
  wire bus4_to_bits4_0_bit0;
  wire bus4_to_bits4_0_bit2;
  wire bus4_to_bits4_1_bit1;
  wire bus8_to_bits8_1_bit1;
  wire bus8_to_bits8_1_bit2;
  wire bus8_to_bits8_1_bit3;
  wire bus8_to_bits8_1_bit4;
  wire bus8_to_bits8_1_bit5;
  wire bus8_to_bits8_1_bit6;
  wire bus8_to_bits8_1_bit7;
  wire bus8_to_bits8_2_bit1;
  wire bus8_to_bits8_2_bit2;
  wire bus8_to_bits8_2_bit3;
  wire bus8_to_bits8_2_bit4;
  wire bus8_to_bits8_3_bit1;
  wire bus8_to_bits8_3_bit2;
  wire bus8_to_bits8_3_bit3;
  wire bus8_to_bits8_3_bit4;
  wire bus8_to_bits8_3_bit5;
  wire bus8_to_bits8_3_bit6;
  wire bus8_to_bits8_3_bit7;
  wire [9:0]bus_mux10_3_0_bus_out;
  wire [3:0]constvald_dout;
  wire [3:0]decoder_2to4_0_out;
  wire [3:0]decoder_2to4_1_out;
  wire [7:0]decoder_3to8_0_out;
  wire [7:0]decoder_3to8_1_out;
  wire [7:0]decoder_3to8_2_out;
  wire [15:0]extend8_to_16_0_out16;
  wire not_gate_0_y;
  wire not_gate_1_y;
  wire [15:0]ram_0_data_out;
  wire [22:0]rom_1kx23_0_data_out;
  wire uIR_0_C0;
  wire uIR_0_DREin;
  wire uIR_0_DREout_bit;
  wire uIR_0_M;
  wire [3:0]uIR_0_S;
  wire uIR_0_Zin;
  wire [2:0]uIR_0_in_sel;
  wire [9:0]uIR_0_jp_addr;
  wire [2:0]uIR_0_out_sel;
  wire [1:0]uIR_0_pc_ctrl;
  wire [1:0]uIR_0_ram_op;
  wire [2:0]uIR_0_tr_type;
  wire [0:0]vcc_dout;

  onlyonce_register_16bit_0_4 IR_RnM
       (.clk(and_gate_7_y),
        .data_in(Z_data_out),
        .data_out(IR),
        .read_en(vcc_dout),
        .reset(RSTT),
        .write_en(bus8_to_bits8_1_bit1));
  onlyonce_IR_0_0 IR_0
       (.IR(IR),
        .mjp_addr(IR_0_mjp_addr),
        .qjp_addr(IR_0_qjp_addr));
  onlyonce_register_16bit_0_7 MAR_RnM
       (.clk(and_gate_10_y),
        .data_in(Z_data_out),
        .data_out(MAR_data_out),
        .read_en(vcc_dout),
        .reset(RSTT),
        .write_en(bus8_to_bits8_1_bit6));
  onlyonce_register_16bit_0_6 MDRR_RnM
       (.clk(and_gate_9_y),
        .data_in(ram_0_data_out),
        .data_out(MDRR),
        .read_en(bus8_to_bits8_3_bit6),
        .reset(RSTT),
        .write_en(uIR_0_DREin));
  onlyonce_register_16bit_0_5 MDRW_RnM
       (.clk(and_gate_8_y),
        .data_in(Z_data_out),
        .data_out(MDRW),
        .read_en(uIR_0_DREout_bit),
        .reset(RSTT),
        .write_en(bus8_to_bits8_1_bit7));
  PC_imp_C1137V PC
       (.CR(RSTT),
        .CT(bus4_to_bits4_1_bit1),
        .LD(vcc_dout),
        .bus_out(PC_bus_out),
        .clk(not_gate_1_y),
        .d(constvald_dout));
  onlyonce_register_16bit_0_1 R0_RnM
       (.clk(and_gate_6_y),
        .data_in(Z_data_out),
        .data_out(R0),
        .read_en(bus8_to_bits8_3_bit2),
        .reset(RSTT),
        .write_en(bus8_to_bits8_1_bit2));
  onlyonce_register_16bit_1_0 R1_RnM
       (.clk(and_gate_5_y),
        .data_in(Z_data_out),
        .data_out(R1),
        .read_en(bus8_to_bits8_3_bit3),
        .reset(RSTT),
        .write_en(bus8_to_bits8_1_bit3));
  onlyonce_register_16bit_2_0 R2_RnM
       (.clk(and_gate_4_y),
        .data_in(Z_data_out),
        .data_out(R2),
        .read_en(bus8_to_bits8_3_bit4),
        .reset(RSTT),
        .write_en(bus8_to_bits8_1_bit4));
  onlyonce_register_16bit_0_3 X
       (.clk(and_gate_3_y),
        .data_in(Z_data_out),
        .data_out(X_data_out),
        .read_en(vcc_dout),
        .reset(RSTT),
        .write_en(bus8_to_bits8_1_bit5));
  onlyonce_register_16bit_0_2 Z_RnM
       (.clk(and_gate_2_y),
        .data_in(adder_bus_out),
        .data_out(Z),
        .read_en(bus8_to_bits8_3_bit5),
        .reset(RSTT),
        .write_en(uIR_0_Zin));
  adder_imp_1CXOY90 adder
       (.bus_in(Z_data_out),
        .bus_in1(X_data_out),
        .bus_out(adder_bus_out),
        .cin(uIR_0_C0),
        .m(uIR_0_M),
        .s(uIR_0_S));
  onlyonce_and_gate_1_0 and_gate_1
       (.a(not_gate_0_y),
        .b(not_gate_1_y),
        .y(and_gate_1_y));
  onlyonce_and_gate_10_0 and_gate_10
       (.a(not_gate_1_y),
        .b(bus8_to_bits8_1_bit6),
        .y(and_gate_10_y));
  onlyonce_and_gate_2_0 and_gate_2
       (.a(not_gate_1_y),
        .b(uIR_0_Zin),
        .y(and_gate_2_y));
  onlyonce_and_gate_3_0 and_gate_3
       (.a(not_gate_1_y),
        .b(bus8_to_bits8_1_bit5),
        .y(and_gate_3_y));
  onlyonce_and_gate_4_0 and_gate_4
       (.a(not_gate_1_y),
        .b(bus8_to_bits8_1_bit4),
        .y(and_gate_4_y));
  onlyonce_and_gate_5_0 and_gate_5
       (.a(not_gate_1_y),
        .b(bus8_to_bits8_1_bit3),
        .y(and_gate_5_y));
  onlyonce_and_gate_6_0 and_gate_6
       (.a(not_gate_1_y),
        .b(bus8_to_bits8_1_bit2),
        .y(and_gate_6_y));
  onlyonce_and_gate_7_0 and_gate_7
       (.a(not_gate_1_y),
        .b(bus8_to_bits8_1_bit1),
        .y(and_gate_7_y));
  onlyonce_and_gate_8_0 and_gate_8
       (.a(not_gate_1_y),
        .b(bus8_to_bits8_1_bit7),
        .y(and_gate_8_y));
  onlyonce_and_gate_9_0 and_gate_9
       (.a(not_gate_1_y),
        .b(uIR_0_DREin),
        .y(and_gate_9_y));
  onlyonce_bus4_to_bits4_0_2 bus4_to_bits4_0
       (.bit0(bus4_to_bits4_0_bit0),
        .bit2(bus4_to_bits4_0_bit2),
        .bus_in(decoder_2to4_0_out));
  onlyonce_bus4_to_bits4_1_2 bus4_to_bits4_1
       (.bit1(bus4_to_bits4_1_bit1),
        .bus_in(decoder_2to4_1_out));
  onlyonce_bus8_to_bits8_1_0 bus8_to_bits8_1
       (.bit1(bus8_to_bits8_1_bit1),
        .bit2(bus8_to_bits8_1_bit2),
        .bit3(bus8_to_bits8_1_bit3),
        .bit4(bus8_to_bits8_1_bit4),
        .bit5(bus8_to_bits8_1_bit5),
        .bit6(bus8_to_bits8_1_bit6),
        .bit7(bus8_to_bits8_1_bit7),
        .bus_in(decoder_3to8_1_out));
  onlyonce_bus8_to_bits8_2_0 bus8_to_bits8_2
       (.bit1(bus8_to_bits8_2_bit1),
        .bit2(bus8_to_bits8_2_bit2),
        .bit3(bus8_to_bits8_2_bit3),
        .bit4(bus8_to_bits8_2_bit4),
        .bus_in(decoder_3to8_0_out));
  onlyonce_bus8_to_bits8_3_0 bus8_to_bits8_3
       (.bit1(bus8_to_bits8_3_bit1),
        .bit2(bus8_to_bits8_3_bit2),
        .bit3(bus8_to_bits8_3_bit3),
        .bit4(bus8_to_bits8_3_bit4),
        .bit5(bus8_to_bits8_3_bit5),
        .bit6(bus8_to_bits8_3_bit6),
        .bit7(bus8_to_bits8_3_bit7),
        .bus_in(decoder_3to8_2_out));
  onlyonce_bus_mux10_3_0_0 bus_mux10_3_0
       (.bus_out(bus_mux10_3_0_bus_out),
        .en0(bus8_to_bits8_2_bit2),
        .en1(bus8_to_bits8_2_bit3),
        .en2(bus8_to_bits8_2_bit4),
        .in0(uIR_0_jp_addr),
        .in1(IR_0_qjp_addr),
        .in2(IR_0_mjp_addr));
  onlyonce_bus_mux16_0_0 bus_mux16_0
       (.DRout(MDRR),
        .DRout_en(bus8_to_bits8_3_bit6),
        .IRout(IR),
        .IRout_en(bus8_to_bits8_3_bit1),
        .PCout(extend8_to_16_0_out16),
        .PCout_en(bus8_to_bits8_3_bit7),
        .R0out(R0),
        .R0out_en(bus8_to_bits8_3_bit2),
        .R1out(R1),
        .R1out_en(bus8_to_bits8_3_bit3),
        .R2out(R2),
        .R2out_en(bus8_to_bits8_3_bit4),
        .Zout(Z),
        .Zout_en(bus8_to_bits8_3_bit5),
        .bus_out(Z_data_out));
  onlyonce_xlconstant_0_2 constvald
       (.dout(constvald_dout));
  onlyonce_decoder_2to4_0_1 decoder_2to4_0
       (.addr(uIR_0_ram_op),
        .enable(vcc_dout),
        .out(decoder_2to4_0_out));
  onlyonce_decoder_2to4_1_0 decoder_2to4_1
       (.addr(uIR_0_pc_ctrl),
        .enable(vcc_dout),
        .out(decoder_2to4_1_out));
  onlyonce_decoder_3to8_0_0 decoder_3to8_0
       (.addr(uIR_0_tr_type),
        .enable(vcc_dout),
        .out(decoder_3to8_0_out));
  onlyonce_decoder_3to8_1_0 decoder_3to8_1
       (.addr(uIR_0_in_sel),
        .enable(vcc_dout),
        .out(decoder_3to8_1_out));
  onlyonce_decoder_3to8_2_0 decoder_3to8_2
       (.addr(uIR_0_out_sel),
        .enable(vcc_dout),
        .out(decoder_3to8_2_out));
  onlyonce_extend8_to_16_0_0 extend8_to_16_0
       (.in8(PC_bus_out),
        .out16(extend8_to_16_0_out16));
  onlyonce_not_gate_0_0 not_gate_0
       (.a(bus4_to_bits4_0_bit0),
        .y(not_gate_0_y));
  onlyonce_not_gate_1_0 not_gate_1
       (.a(CLKK),
        .y(not_gate_1_y));
  onlyonce_ram_0_0 ram_0
       (.addr(MAR),
        .clk(and_gate_1_y),
        .data_in(MDRW),
        .data_out(ram_0_data_out),
        .we(bus4_to_bits4_0_bit2));
  onlyonce_rom_1kx23_0_1 rom_1kx23_0
       (.addr(bits10_to_bus10_0_bus_out),
        .clk(not_gate_1_y),
        .data_out(rom_1kx23_0_data_out),
        .en(vcc_dout));
  onlyonce_truncate16_to_8_0_0 truncate16_to_8_0
       (.in16(MAR_data_out),
        .out8(MAR));
  onlyonce_uIR_0_0 uIR_0
       (.C0(uIR_0_C0),
        .DREin(uIR_0_DREin),
        .DREout_bit(uIR_0_DREout_bit),
        .M(uIR_0_M),
        .S(uIR_0_S),
        .Zin(uIR_0_Zin),
        .in_sel(uIR_0_in_sel),
        .jp_addr(uIR_0_jp_addr),
        .microIR(rom_1kx23_0_data_out),
        .out_sel(uIR_0_out_sel),
        .pc_ctrl(uIR_0_pc_ctrl),
        .ram_op(uIR_0_ram_op),
        .tr_type(uIR_0_tr_type));
  uPC_imp_1KJ2JA9 uPC
       (.CR(RSTT),
        .CT_t(vcc_dout),
        .LD(bus8_to_bits8_2_bit1),
        .bus_out(bits10_to_bus10_0_bus_out),
        .clk(CLKK),
        .in10(bus_mux10_3_0_bus_out));
  onlyonce_xlconstant_0_0 vcc
       (.dout(vcc_dout));
endmodule

module uPC_imp_1KJ2JA9
   (CR,
    CT_t,
    LD,
    bus_out,
    clk,
    in10);
  input CR;
  input CT_t;
  input LD;
  output [9:0]bus_out;
  input clk;
  input [9:0]in10;

  wire CR;
  wire CT_t;
  wire LD;
  wire [3:0]bus10_to_3x4_0_out_high;
  wire [3:0]bus10_to_3x4_0_out_low;
  wire [3:0]bus10_to_3x4_0_out_mid;
  wire bus4_to_bits4_1_bit0;
  wire bus4_to_bits4_1_bit1;
  wire bus4_to_bits4_2_bit0;
  wire bus4_to_bits4_2_bit1;
  wire bus4_to_bits4_2_bit2;
  wire bus4_to_bits4_2_bit3;
  wire bus4_to_bits4_3_bit0;
  wire bus4_to_bits4_3_bit1;
  wire bus4_to_bits4_3_bit2;
  wire bus4_to_bits4_3_bit3;
  wire [9:0]bus_out;
  wire clk;
  wire ic_74161_0_CO;
  wire [3:0]ic_74161_0_q;
  wire ic_74161_1_CO;
  wire [3:0]ic_74161_1_q;
  wire [3:0]ic_74161_2_q;
  wire [9:0]in10;

  onlyonce_bits10_to_bus10_0_0 bits10_to_bus10_0
       (.bit0(bus4_to_bits4_3_bit0),
        .bit1(bus4_to_bits4_3_bit1),
        .bit2(bus4_to_bits4_3_bit2),
        .bit3(bus4_to_bits4_3_bit3),
        .bit4(bus4_to_bits4_2_bit0),
        .bit5(bus4_to_bits4_2_bit1),
        .bit6(bus4_to_bits4_2_bit2),
        .bit7(bus4_to_bits4_2_bit3),
        .bit8(bus4_to_bits4_1_bit0),
        .bit9(bus4_to_bits4_1_bit1),
        .bus_out(bus_out));
  onlyonce_bus10_to_3x4_0_0 bus10_to_3x4_0
       (.in10(in10),
        .out_high(bus10_to_3x4_0_out_high),
        .out_low(bus10_to_3x4_0_out_low),
        .out_mid(bus10_to_3x4_0_out_mid));
  onlyonce_bus4_to_bits4_1_0 bus4_to_bits4_1
       (.bit0(bus4_to_bits4_1_bit0),
        .bit1(bus4_to_bits4_1_bit1),
        .bus_in(ic_74161_2_q));
  onlyonce_bus4_to_bits4_2_0 bus4_to_bits4_2
       (.bit0(bus4_to_bits4_2_bit0),
        .bit1(bus4_to_bits4_2_bit1),
        .bit2(bus4_to_bits4_2_bit2),
        .bit3(bus4_to_bits4_2_bit3),
        .bus_in(ic_74161_1_q));
  onlyonce_bus4_to_bits4_3_0 bus4_to_bits4_3
       (.bit0(bus4_to_bits4_3_bit0),
        .bit1(bus4_to_bits4_3_bit1),
        .bit2(bus4_to_bits4_3_bit2),
        .bit3(bus4_to_bits4_3_bit3),
        .bus_in(ic_74161_0_q));
  onlyonce_ic_74161_0_0 ic_74161_0
       (.CO(ic_74161_0_CO),
        .CR(CR),
        .CT_p(CT_t),
        .CT_t(CT_t),
        .LD(LD),
        .clk(clk),
        .d(bus10_to_3x4_0_out_low),
        .q(ic_74161_0_q));
  onlyonce_ic_74161_1_0 ic_74161_1
       (.CO(ic_74161_1_CO),
        .CR(CR),
        .CT_p(ic_74161_0_CO),
        .CT_t(ic_74161_0_CO),
        .LD(LD),
        .clk(clk),
        .d(bus10_to_3x4_0_out_mid),
        .q(ic_74161_1_q));
  onlyonce_ic_74161_2_0 ic_74161_2
       (.CR(CR),
        .CT_p(ic_74161_1_CO),
        .CT_t(ic_74161_1_CO),
        .LD(LD),
        .clk(clk),
        .d(bus10_to_3x4_0_out_high),
        .q(ic_74161_2_q));
endmodule
